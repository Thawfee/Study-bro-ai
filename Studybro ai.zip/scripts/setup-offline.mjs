#!/usr/bin/env node
/* ============================================================
   StudyBro AI — offline model setup.

   Makes the live AI work WITHOUT internet (e.g. on bad expo Wi-Fi):

     1. Copies the MediaPipe WASM runtime from node_modules into
        public/mediapipe/wasm            (no internet needed)
     2. Downloads the MediaPipe face model into
        public/models/face_landmarker.task
     3. Downloads the COCO-SSD (lite_mobilenet_v2) phone detector into
        public/models/coco-ssd/

   Usage:
     npm run setup-offline          # everything (needs internet ONCE)
     node scripts/setup-offline.mjs --wasm-only

   The app automatically uses these local files when they exist and
   falls back to the public CDNs when they don't.
   ============================================================ */

import { copyFile, mkdir, stat, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pub = path.join(root, "public");
const wasmOnly = process.argv.includes("--wasm-only");

const FACE_MODEL_URL =
  "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
const COCO_BASE = "https://storage.googleapis.com/tfjs-models/savedmodel/ssdlite_mobilenet_v2";

const WASM_FILES = [
  "vision_wasm_internal.js",
  "vision_wasm_internal.wasm",
  "vision_wasm_nosimd_internal.js",
  "vision_wasm_nosimd_internal.wasm",
];

async function copyWasm() {
  const src = path.join(root, "node_modules", "@mediapipe", "tasks-vision", "wasm");
  const dest = path.join(pub, "mediapipe", "wasm");
  if (!existsSync(src)) {
    console.warn("[setup-offline] @mediapipe/tasks-vision is not installed yet — run npm install first.");
    return false;
  }
  await mkdir(dest, { recursive: true });
  for (const f of WASM_FILES) await copyFile(path.join(src, f), path.join(dest, f));
  console.log("[setup-offline] ✓ MediaPipe WASM runtime → public/mediapipe/wasm");
  return true;
}

async function download(url, file) {
  if (existsSync(file) && (await stat(file)).size > 0) {
    console.log(`[setup-offline] ✓ already present: ${path.relative(root, file)}`);
    return;
  }
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} for ${url}`);
  await mkdir(path.dirname(file), { recursive: true });
  await writeFile(file, Buffer.from(await res.arrayBuffer()));
  console.log(`[setup-offline] ✓ downloaded ${path.relative(root, file)}`);
}

async function downloadModels() {
  await download(FACE_MODEL_URL, path.join(pub, "models", "face_landmarker.task"));

  const cocoDir = path.join(pub, "models", "coco-ssd");
  const manifestFile = path.join(cocoDir, "model.json");
  await download(`${COCO_BASE}/model.json`, manifestFile);
  const { readFile } = await import("node:fs/promises");
  const manifest = JSON.parse(await readFile(manifestFile, "utf8"));
  for (const group of manifest.weightsManifest ?? []) {
    for (const p of group.paths) await download(`${COCO_BASE}/${p}`, path.join(cocoDir, p));
  }
}

(async () => {
  try {
    await copyWasm();
  } catch (err) {
    console.warn("[setup-offline] could not copy WASM runtime:", err.message);
  }
  if (wasmOnly) return;
  try {
    await downloadModels();
    console.log("\n[setup-offline] Done — StudyBro's AI will now start without internet.");
  } catch (err) {
    console.warn(
      `\n[setup-offline] Model download failed (${err.message}).\n` +
        "The app still works online: it falls back to the public CDNs.\n" +
        "Re-run `npm run setup-offline` on a machine with internet to enable offline mode.",
    );
  }
})();
