"use client";

import { useStudyBro } from "@/lib/store/studybro-store";
import type { DetectionType } from "@/types/ai";

/**
 * Thin wrapper over the store exposing the Demo Control Panel actions.
 * When the real AI backend is added, the demo triggers become optional
 * dev tooling and the same store consumes live detections instead.
 */
export function useDemoAI() {
  const { trigger, reset, detections, focus } = useStudyBro();

  return {
    detections,
    focus,
    triggerSleep: () => trigger("drowsiness"),
    triggerPhone: () => trigger("phone"),
    triggerDistraction: () => trigger("distraction"),
    triggerBadPosture: () => trigger("posture"),
    triggerAway: () => trigger("away"),
    triggerByType: (type: DetectionType) => trigger(type),
    reset,
  };
}
