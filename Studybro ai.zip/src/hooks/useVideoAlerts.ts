"use client";

import { useStudyBro } from "@/lib/store/studybro-store";

/** Thin wrapper exposing video-alert + toast state from the store. */
export function useVideoAlerts() {
  const { activeAlert, closeAlert, toasts, dismissToast, settings } = useStudyBro();
  return { activeAlert, closeAlert, toasts, dismissToast, settings };
}
