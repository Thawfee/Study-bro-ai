"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export interface StudyTimerState {
  secondsLeft: number;
  totalSeconds: number;
  isRunning: boolean;
  isFinished: boolean;
  /** 0–1 elapsed fraction (for progress rings). */
  progress: number;
  start: () => void;
  pause: () => void;
  reset: () => void;
  setMinutes: (minutes: number) => void;
}

/** Reusable Pomodoro-style countdown timer. Defaults to 25:00.
 *  `onFinish` fires exactly once when a countdown reaches 0:00. */
export function useStudyTimer(initialMinutes = 25, onFinish?: () => void): StudyTimerState {
  const [totalSeconds, setTotalSeconds] = useState(initialMinutes * 60);
  const [secondsLeft, setSecondsLeftState] = useState(initialMinutes * 60);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const secondsRef = useRef(initialMinutes * 60);
  const onFinishRef = useRef(onFinish);
  useEffect(() => {
    onFinishRef.current = onFinish;
  });

  const setSecondsLeft = useCallback((value: number) => {
    secondsRef.current = value;
    setSecondsLeftState(value);
  }, []);

  const clear = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (!isRunning) return;
    intervalRef.current = setInterval(() => {
      const next = secondsRef.current - 1;
      if (next <= 0) {
        clear();
        setSecondsLeft(0);
        setIsRunning(false);
        onFinishRef.current?.(); // outside any state updater → fires once
      } else {
        setSecondsLeft(next);
      }
    }, 1000);
    return clear;
  }, [isRunning, clear, setSecondsLeft]);

  const start = useCallback(() => {
    if (secondsRef.current <= 0) setSecondsLeft(totalSeconds);
    setIsRunning(true);
  }, [totalSeconds, setSecondsLeft]);

  const pause = useCallback(() => setIsRunning(false), []);

  const reset = useCallback(() => {
    clear();
    setIsRunning(false);
    setSecondsLeft(totalSeconds);
  }, [clear, totalSeconds, setSecondsLeft]);

  const setMinutes = useCallback((minutes: number) => {
    const secs = Math.max(1, Math.round(minutes)) * 60;
    clear();
    setIsRunning(false);
    setTotalSeconds(secs);
    setSecondsLeft(secs);
  }, [clear, setSecondsLeft]);

  const progress = totalSeconds > 0 ? 1 - secondsLeft / totalSeconds : 0;

  return {
    secondsLeft,
    totalSeconds,
    isRunning,
    isFinished: secondsLeft === 0,
    progress,
    start,
    pause,
    reset,
    setMinutes,
  };
}
