"use client";

import { useCallback, useMemo, useSyncExternalStore } from "react";

/* ============================================================
   useStoredState — JSON state backed by localStorage.

   Why this exists: the previous pattern ("read storage in one effect,
   write storage in another") wrote the EMPTY initial value before the
   saved value had loaded. Under React Strict Mode (the default in
   `next dev`) that erased saved data on every visit.

   Here, localStorage is the single source of truth (read through
   useSyncExternalStore), and writes only happen from explicit user
   actions — never as a side effect of rendering or mounting.
   ============================================================ */

const LOCAL_EVENT = "studybro:storage";

function subscribe(onChange: () => void): () => void {
  window.addEventListener("storage", onChange);
  window.addEventListener(LOCAL_EVENT, onChange);
  return () => {
    window.removeEventListener("storage", onChange);
    window.removeEventListener(LOCAL_EVENT, onChange);
  };
}

export function readStored(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function parse<T>(raw: string | null, fallback: T): T {
  if (raw == null) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function writeStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage blocked or full — keep the app running */
  }
  if (typeof window !== "undefined") window.dispatchEvent(new Event(LOCAL_EVENT));
}

/** `fallback` should be a stable value (e.g. a module-level constant). */
export function useStoredState<T>(
  key: string,
  fallback: T,
): [T, (next: T | ((prev: T) => T)) => void] {
  const raw = useSyncExternalStore(
    subscribe,
    () => readStored(key),
    () => null, // server render: always the fallback
  );
  const value = useMemo(() => parse(raw, fallback), [raw, fallback]);

  const set = useCallback(
    (next: T | ((prev: T) => T)) => {
      // Always derive from what is actually stored right now, so a stale
      // closure can never overwrite newer saved data.
      const current = parse(readStored(key), fallback);
      const resolved = typeof next === "function" ? (next as (prev: T) => T)(current) : next;
      writeStored(key, resolved);
    },
    [key, fallback],
  );

  return [value, set];
}
