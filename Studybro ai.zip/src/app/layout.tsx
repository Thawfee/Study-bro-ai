import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ThemeProvider, themeInitScript } from "@/components/theme/ThemeProvider";

// Fonts are bundled locally (SIL OFL, see fonts/GEIST-OFL-LICENSE.txt) so the
// build and the app work with no internet connection — e.g. on expo Wi-Fi.
const geistSans = localFont({ src: "./fonts/Geist-Variable.woff2", variable: "--font-geist-sans", weight: "100 900", display: "swap" });
const geistMono = localFont({ src: "./fonts/GeistMono-Variable.woff2", variable: "--font-geist-mono", weight: "100 900", display: "swap" });

export const metadata: Metadata = {
  title: {
    default: "StudyBro AI — Your AI Study Bro",
    template: "%s · StudyBro AI",
  },
  description:
    "Study smarter, stay focused, and build better habits with StudyBro AI — an AI companion that watches your focus, not your privacy.",
  keywords: ["study", "focus", "AI", "pomodoro", "productivity", "student", "computer vision"],
  openGraph: {
    title: "StudyBro AI — Your AI Study Bro",
    description: "Study smarter, stay focused, and build better habits with StudyBro AI.",
    type: "website",
  },
  applicationName: "StudyBro AI",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${geistSans.variable} ${geistMono.variable} h-full antialiased dark`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body className="min-h-full flex flex-col bg-ambient">
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
