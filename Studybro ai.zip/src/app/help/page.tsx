import type { Metadata } from "next";
import { PublicNav } from "@/components/layout/PublicNav";
import { Footer } from "@/components/layout/Footer";

export const metadata: Metadata = { title: "Help & FAQ" };

const SECTIONS = [
  {
    title: "Getting started",
    items: [
      { q: "How do I start a focus session?", a: "Open the Dashboard and click “Start Focus Session”, or go to the Focus Monitor and enable your camera." },
      { q: "Do I need to create an account?", a: "No — this build is local-first. You can jump straight into the app as a guest; your tasks, goals and notes are saved in your browser." },
    ],
  },
  {
    title: "AI Focus Monitor",
    items: [
      { q: "What does the camera detect?", a: "Drowsiness (via eye-aspect-ratio), phone usage (object detection), distraction/gaze, posture and whether you're present at your desk." },
      { q: "Is my video uploaded?", a: "No. All detection runs in your browser on-device. Nothing is recorded or uploaded by default." },
      { q: "The overlay/models won't load.", a: "The first camera start downloads the AI models from a CDN, so you need an internet connection the first time. After that they're cached." },
    ],
  },
  {
    title: "Video alerts",
    items: [
      { q: "Why did a video pop up?", a: "StudyBro plays a short video when it detects you've drifted (phone, drowsiness, etc.). You can tune or disable this in Settings → Video Alerts." },
      { q: "How do I stop the pop-ups spamming me?", a: "There's a built-in 30-second cooldown per detection type. You can change the cooldown in Settings." },
    ],
  },
];

export default function HelpPage() {
  return (
    <div>
      <PublicNav />
      <main className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
        <h1 className="text-3xl font-bold tracking-tight text-[var(--text)]">Help & FAQ</h1>
        <p className="mt-2 text-sm text-[var(--text-dim)]">Everything you need to get the most out of StudyBro AI.</p>

        <div className="mt-10 space-y-10">
          {SECTIONS.map((s) => (
            <section key={s.title}>
              <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-violet-300">{s.title}</h2>
              <div className="space-y-3">
                {s.items.map((it) => (
                  <details key={it.q} className="card group p-5">
                    <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-[var(--text)]">
                      {it.q}
                      <span className="text-[var(--text-faint)] transition-transform group-open:rotate-45">+</span>
                    </summary>
                    <p className="mt-3 text-sm leading-relaxed text-[var(--text-dim)]">{it.a}</p>
                  </details>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="mt-12 card p-6 text-center">
          <p className="text-sm text-[var(--text-dim)]">Still stuck, Bro? This is a student project — reach out to the team that built it.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
