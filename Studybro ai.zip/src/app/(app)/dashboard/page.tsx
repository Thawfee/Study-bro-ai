"use client";

import Link from "next/link";
import { Clock, Gauge, Flame, Target, ArrowRight, ListTodo } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { useWorkspace } from "@/lib/store/workspace-store";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { StatCard } from "@/components/dashboard/StatCard";
import { QuickFocus } from "@/components/dashboard/QuickFocus";
import { DailyProgress } from "@/components/dashboard/DailyProgress";
import { EventFeed } from "@/components/dashboard/EventFeed";
import { TaskRow } from "@/components/tasks/TaskRow";
import { formatDuration } from "@/lib/utils";

export default function DashboardPage() {
  const { focus, session } = useStudyBro();
  const { tasks, goals, profile, toggleTask } = useWorkspace();

  const goalsDone = goals.filter((g) => g.current >= g.target).length;
  const todaysTasks = tasks.filter((t) => !t.done).slice(0, 4);

  return (
    <div className="space-y-6">
      <DashboardHeader />

      {/* Stat grid */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon={Clock} label="Today's Study Time" value={formatDuration(session.metrics.studyTimeMs)} hint="This session" tone="brand" />
        <StatCard icon={Gauge} label="Focus Score" value={`${focus.score}%`} hint={focus.status} tone="cyan" />
        <StatCard icon={Flame} label="Current Streak" value={`${profile.streakDays} days`} hint="Keep it alive 🔥" tone="amber" />
        <StatCard icon={Target} label="Goals Completed" value={`${goalsDone}/${goals.length}`} hint="This period" tone="good" />
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="space-y-6">
          <QuickFocus />

          {/* Today's tasks */}
          <div className="card p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-lg border border-violet-400/30 bg-violet-500/10 text-violet-300">
                  <ListTodo size={16} />
                </span>
                <h3 className="text-sm font-semibold text-[var(--text)]">Today&apos;s Tasks</h3>
              </div>
              <Link href="/tasks" className="inline-flex items-center gap-1 text-xs text-violet-300 hover:text-violet-200">
                View all <ArrowRight size={13} />
              </Link>
            </div>
            {todaysTasks.length === 0 ? (
              <p className="py-6 text-center text-sm text-[var(--text-faint)]">All clear, Bro. Nothing pending. 🎉</p>
            ) : (
              <div className="space-y-2">
                {todaysTasks.map((t) => (
                  <TaskRow key={t.id} task={t} onToggle={() => toggleTask(t.id)} />
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <DailyProgress />
          <EventFeed limit={6} />
        </div>
      </div>
    </div>
  );
}
