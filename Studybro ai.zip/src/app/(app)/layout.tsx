import { StudyBroProvider } from "@/lib/store/studybro-store";
import { WorkspaceProvider } from "@/lib/store/workspace-store";
import { AppShell } from "@/components/layout/AppShell";
import { VideoAlertHost } from "@/components/alerts/VideoAlertHost";
import { ToastHost } from "@/components/alerts/AlertToast";

export default function AppGroupLayout({ children }: { children: React.ReactNode }) {
  return (
    <WorkspaceProvider>
      <StudyBroProvider>
        <AppShell>{children}</AppShell>
        <ToastHost />
        <VideoAlertHost />
      </StudyBroProvider>
    </WorkspaceProvider>
  );
}
