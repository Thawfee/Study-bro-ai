import Link from "next/link";
import { Beaker, Presentation, Sparkles } from "lucide-react";
import { StudyMetrics } from "@/components/dashboard/StudyMetrics";
import { FocusTrend } from "@/components/charts/FocusTrend";
import { TimeDistribution } from "@/components/charts/TimeDistribution";
import { DetectionBreakdown } from "@/components/charts/DetectionBreakdown";
import { DemoControlPanel } from "@/components/dashboard/DemoControlPanel";
import { LiveModeBadge } from "@/components/brand/LiveModeBadge";
import { PersonalBaselinePanel } from "@/components/dashboard/PersonalBaselinePanel";
import { SessionSummaryPanel } from "@/components/dashboard/SessionSummaryPanel";
import { AIArchitecturePanel } from "@/components/dashboard/AIArchitecturePanel";

export default function AnalyticsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-violet-200"><Sparkles size={13}/> Recovery Analytics</div>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-[var(--text)]">Study Analytics</h1>
          <p className="mt-1 max-w-2xl text-sm text-[var(--text-dim)]">Live session evidence, focus health, recovery behavior and your personal baseline — all derived from StudyBro session data.</p>
        </div>
        <div className="flex flex-wrap gap-2"><Link href="/lab" className="inline-flex items-center gap-2 rounded-xl border border-cyan-400/20 bg-cyan-500/10 px-3 py-2 text-xs font-semibold text-cyan-200"><Beaker size={14}/> AI Test Lab</Link><Link href="/expo" className="inline-flex items-center gap-2 rounded-xl border border-amber-400/20 bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-200"><Presentation size={14}/> Expo Mode</Link><LiveModeBadge /></div>
      </div>

      <StudyMetrics />
      <SessionSummaryPanel />

      <FocusTrend />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <TimeDistribution />
        <DetectionBreakdown />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <PersonalBaselinePanel />
        <DemoControlPanel />
      </div>

      <AIArchitecturePanel />

      <div className="card p-5">
        <h3 className="text-sm font-semibold text-[var(--text)]">About this data</h3>
        <p className="mt-2 text-sm leading-relaxed text-[var(--text-dim)]">Session analytics are calculated from the active StudyBro engine. Live camera mode uses in-browser computer-vision inference; Demo Mode is clearly labeled and exists only for controlled presentation. AI Test Lab statistics stay empty until you enter your own experiment results, so the project never invents accuracy claims.</p>
      </div>
    </div>
  );
}
