"use client";

import { useEffect, useRef, useState } from "react";
import { Play, Pause, RotateCcw, Coffee, Brain, Zap, Timer as TimerIcon } from "lucide-react";
import { useStudyTimer } from "@/hooks/useStudyTimer";
import { useWorkspace } from "@/lib/store/workspace-store";
import { PageHeader } from "@/components/ui/common";
import { Input } from "@/components/ui/Field";
import { formatClock, cn } from "@/lib/utils";

const MODES = [
  { key: "pomodoro", label: "Pomodoro", minutes: 25, icon: Zap, tone: "violet" },
  { key: "deep", label: "Deep Work", minutes: 50, icon: Brain, tone: "cyan" },
  { key: "short", label: "Short Break", minutes: 5, icon: Coffee, tone: "emerald" },
  { key: "long", label: "Long Break", minutes: 15, icon: Coffee, tone: "amber" },
] as const;

export default function TimerPage() {
  const { updateProfile, profile } = useWorkspace();
  const [mode, setMode] = useState("pomodoro");
  const [custom, setCustom] = useState(30);
  const [completed, setCompleted] = useState(0);
  const latest = useRef({ mode, profile, updateProfile });
  useEffect(() => {
    latest.current = { mode, profile, updateProfile };
  });

  // Record a completed session (study modes only) when the countdown ends.
  const timer = useStudyTimer(25, () => {
    const { mode: m, profile: p, updateProfile: update } = latest.current;
    const cfg = MODES.find((x) => x.key === m);
    if (cfg && (cfg.key === "pomodoro" || cfg.key === "deep")) {
      setCompleted((c) => c + 1);
      update({ totalStudyMs: p.totalStudyMs + cfg.minutes * 60e3 });
    }
  });

  const pickMode = (key: string, minutes: number) => {
    setMode(key);
    timer.setMinutes(minutes);
  };

  const size = 300;
  const stroke = 14;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - timer.progress * c;
  const isBreak = mode === "short" || mode === "long";

  return (
    <div className="space-y-6">
      <PageHeader title="Study Timer" subtitle="Pick a mode, hit start, get in the zone." />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1.4fr_1fr]">
        {/* Timer */}
        <div className="card flex flex-col items-center p-8">
          <div className="mb-6 flex flex-wrap justify-center gap-2">
            {MODES.map((m) => {
              const Icon = m.icon;
              const active = mode === m.key;
              return (
                <button
                  key={m.key}
                  onClick={() => pickMode(m.key, m.minutes)}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors",
                    active ? "border-violet-400/40 bg-violet-500/15 text-violet-200" : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:text-[var(--text)]",
                  )}
                >
                  <Icon size={14} /> {m.label}
                </button>
              );
            })}
            <button
              onClick={() => pickMode("custom", custom)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors",
                mode === "custom" ? "border-violet-400/40 bg-violet-500/15 text-violet-200" : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:text-[var(--text)]",
              )}
            >
              <TimerIcon size={14} /> Custom
            </button>
          </div>

          {mode === "custom" && (
            <div className="mb-6 flex items-center gap-2">
              <span className="text-sm text-[var(--text-dim)]">Minutes:</span>
              <Input
                type="number"
                min={1}
                max={180}
                value={custom}
                onChange={(e) => { const v = Number(e.target.value); setCustom(v); timer.setMinutes(v || 1); }}
                className="w-24"
              />
            </div>
          )}

          <div className="relative grid place-items-center" style={{ width: size, height: size }}>
            <svg width={size} height={size} className="-rotate-90">
              <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-2)" strokeWidth={stroke} />
              <circle
                cx={size / 2} cy={size / 2} r={r} fill="none"
                stroke={isBreak ? "#34d399" : "#8b5cf6"}
                strokeWidth={stroke} strokeLinecap="round"
                strokeDasharray={c} strokeDashoffset={offset}
                style={{ transition: "stroke-dashoffset 1s linear", filter: `drop-shadow(0 0 8px ${isBreak ? "#34d39966" : "#8b5cf666"})` }}
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-6xl font-bold tabular-nums text-[var(--text)]">{formatClock(timer.secondsLeft)}</span>
              <span className="mt-1 text-xs uppercase tracking-widest text-[var(--text-faint)]">
                {timer.isFinished ? (isBreak ? "Break over ☕" : "Session done 🎉") : timer.isRunning ? (isBreak ? "On a break" : "Locked in 🔥") : "Ready"}
              </span>
            </div>
          </div>

          <div className="mt-8 flex items-center gap-3">
            {timer.isRunning ? (
              <button onClick={timer.pause} className="inline-flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-6 py-3 text-sm font-medium text-[var(--text)] hover:bg-[var(--surface-2)]">
                <Pause size={16} /> Pause
              </button>
            ) : (
              <button onClick={timer.start} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-indigo-500 px-8 py-3 text-sm font-semibold text-white shadow-lg shadow-violet-500/25 hover:brightness-110">
                <Play size={16} /> {timer.secondsLeft < timer.totalSeconds && !timer.isFinished ? "Resume" : "Start"}
              </button>
            )}
            <button onClick={timer.reset} aria-label="Reset" className="grid h-12 w-12 place-items-center rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:bg-[var(--surface-2)]">
              <RotateCcw size={18} />
            </button>
          </div>
        </div>

        {/* Side info */}
        <div className="space-y-6">
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-[var(--text)]">Today&apos;s Sessions</h3>
            <p className="mt-3 text-4xl font-bold text-[var(--text)]">{completed}</p>
            <p className="mt-1 text-xs text-[var(--text-faint)]">Completed focus sessions</p>
          </div>
          <div className="card p-5">
            <h3 className="mb-3 text-sm font-semibold text-[var(--text)]">How the Pomodoro flow works</h3>
            <ol className="space-y-2 text-sm text-[var(--text-dim)]">
              {["Focus for 25 minutes", "Take a 5-minute short break", "Repeat 4 times", "Then take a 15-minute long break"].map((s, i) => (
                <li key={i} className="flex items-center gap-2">
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-violet-500/15 text-[11px] font-bold text-violet-300">{i + 1}</span>
                  {s}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
