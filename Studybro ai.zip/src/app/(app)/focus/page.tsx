import { LiveAIMonitor } from "@/components/camera/LiveAIMonitor";
import { StudyTimer } from "@/components/timer/StudyTimer";
import { DetectionGrid } from "@/components/detections/DetectionGrid";
import { DemoControlPanel } from "@/components/dashboard/DemoControlPanel";
import { EventFeed } from "@/components/dashboard/EventFeed";
import { AIExplanationPanel } from "@/components/dashboard/AIExplanationPanel";
import { LiveModeBadge } from "@/components/brand/LiveModeBadge";
import { FocusFusionHero } from "@/components/dashboard/FocusFusionHero";
import { StudyMetrics } from "@/components/dashboard/StudyMetrics";
import { FocusFactors } from "@/components/dashboard/FocusFactors";
import { FocusTimelinePanel } from "@/components/dashboard/FocusTimelinePanel";
import { PersonalBaselinePanel } from "@/components/dashboard/PersonalBaselinePanel";
import { SessionSummaryPanel } from "@/components/dashboard/SessionSummaryPanel";
import { AIArchitecturePanel } from "@/components/dashboard/AIArchitecturePanel";
import { JudgeDemoPanel } from "@/components/dashboard/JudgeDemoPanel";
import Link from "next/link";
import { Beaker, Presentation } from "lucide-react";

export default function FocusPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-violet-200">
            Expo-grade experience
          </div>
          <h1 className="mt-3 text-2xl font-bold tracking-tight text-[var(--text)] sm:text-4xl">
            Focus Monitor
          </h1>
          <p className="mt-1 max-w-2xl text-sm text-[var(--text-dim)]">
            Premium real-time study monitoring with a cleaner AI HUD, explainable study-state analysis, intervention intelligence and a more polished detection experience.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 self-start">
          <Link href="/expo" className="inline-flex items-center gap-2 rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-200"><Presentation size={14}/> Expo Mode</Link>
          <Link href="/lab" className="inline-flex items-center gap-2 rounded-xl border border-cyan-400/25 bg-cyan-500/10 px-3 py-2 text-xs font-semibold text-cyan-200"><Beaker size={14}/> AI Test Lab</Link>
          <LiveModeBadge />
        </div>
      </div>

      <FocusFusionHero />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1.55fr_0.95fr]">
        <LiveAIMonitor />
        <div className="grid grid-cols-1 gap-6">
          <StudyTimer />
          <div className="card p-5">
            <FocusFactors />
          </div>
        </div>
      </div>

      <StudyMetrics />

      <AIArchitecturePanel />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <PersonalBaselinePanel />
        <SessionSummaryPanel />
      </div>

      <JudgeDemoPanel />

      <section className="space-y-3">
        <div>
          <h2 className="text-lg font-semibold text-[var(--text)]">Detection Intelligence</h2>
          <p className="text-sm text-[var(--text-dim)]">Each detector now lives inside a more premium card system with clearer state and confidence display.</p>
        </div>
        <DetectionGrid />
      </section>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1.1fr_0.9fr_0.9fr]">
        <FocusTimelinePanel />
        <AIExplanationPanel />
        <EventFeed />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-1">
          <DemoControlPanel />
        </div>
        <div className="card p-5 lg:col-span-2">
          <h3 className="text-sm font-semibold text-[var(--text)]">Project Story</h3>
          <p className="mt-2 text-sm leading-relaxed text-[var(--text-dim)]">
            StudyBro AI is more than a webcam detector. It combines face presence, eye state, drowsiness, gaze direction, head-orientation cues, phone detection, posture and recent session history into an explainable study state. The result is a product that can detect, understand, intervene and measure recovery instead of simply flashing a popup.
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {[
              { title: "Detect", desc: "Face, eyes, phone, gaze, posture, presence" },
              { title: "Understand", desc: "Focus Fusion Engine determines the study state" },
              { title: "Intervene", desc: "Soft warnings and videos appear only when needed" },
              { title: "Measure", desc: "Timeline, session metrics and recovery insight" },
            ].map((item) => (
              <div key={item.title} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/75 p-3.5">
                <p className="text-sm font-semibold text-[var(--text)]">{item.title}</p>
                <p className="mt-1 text-xs leading-relaxed text-[var(--text-dim)]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
