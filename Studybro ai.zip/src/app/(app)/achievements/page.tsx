"use client";

import { Lock } from "lucide-react";
import { useWorkspace } from "@/lib/store/workspace-store";
import { useStudyBro } from "@/lib/store/studybro-store";
import { PageHeader, ProgressBar } from "@/components/ui/common";
import type { Achievement } from "@/types/user";
import { cn } from "@/lib/utils";

export default function AchievementsPage() {
  const { profile, tasks, goals, notes } = useWorkspace();
  const { session } = useStudyBro();
  const hours = profile.totalStudyMs / 3600e3;
  const tasksDone = tasks.filter((t) => t.done).length;
  const goalsDone = goals.filter((g) => g.current >= g.target).length;

  const clamp = (v: number) => Math.max(0, Math.min(1, v));
  const make = (icon: string, title: string, description: string, progress: number): Achievement => ({
    id: title,
    icon,
    title,
    description,
    progress: clamp(progress),
    unlocked: progress >= 1,
  });

  const achievements: Achievement[] = [
    make("🎯", "First Study Session", "Complete your very first focus session.", hours > 0 ? 1 : 0),
    make("🔥", "3-Day Streak", "Study 3 days in a row.", profile.streakDays / 3),
    make("🔥", "7-Day Streak", "Keep the streak alive for a full week.", profile.streakDays / 7),
    make("⏳", "10 Hours Focused", "Log 10 hours of focused study.", hours / 10),
    make("🏆", "100 Hours Studied", "Reach 100 total study hours.", hours / 100),
    make("✅", "Task Master", "Complete 10 tasks.", tasksDone / 10),
    make("📝", "Note Taker", "Write 5 study notes.", notes.length / 5),
    make("🎖️", "Goal Getter", "Complete 3 goals.", goalsDone / 3),
    make("📱", "Phone-Free Session", "Study for at least 25 minutes with zero phone usage in the current session.", session.metrics.studyTimeMs >= 25 * 60_000 && session.metrics.phoneUsageMs === 0 ? 1 : session.metrics.studyTimeMs / (25 * 60_000)),
    make("😴", "Beat Drowsiness", "Study for at least 25 minutes with no recorded drowsiness in the current session.", session.metrics.studyTimeMs >= 25 * 60_000 && session.metrics.drowsinessMs === 0 ? 1 : session.metrics.studyTimeMs / (25 * 60_000)),
  ];

  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div className="space-y-6">
      <PageHeader title="Achievements" subtitle={`${unlockedCount} of ${achievements.length} unlocked — keep grinding, Bro. 🏆`} />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {achievements.map((a) => (
          <div
            key={a.id}
            className={cn(
              "card relative overflow-hidden p-5 transition-all",
              a.unlocked ? "border-amber-400/30" : "opacity-70",
            )}
          >
            {a.unlocked && (
              <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-amber-500/15 blur-2xl" />
            )}
            <div className="relative flex items-start gap-3">
              <span
                className={cn(
                  "grid h-12 w-12 shrink-0 place-items-center rounded-xl border text-2xl",
                  a.unlocked ? "border-amber-400/40 bg-amber-500/10" : "border-[var(--border)] bg-[var(--surface)] grayscale",
                )}
              >
                {a.unlocked ? a.icon : <Lock size={18} className="text-[var(--text-faint)]" />}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-[var(--text)]">{a.title}</h3>
                  {a.unlocked && <span className="rounded-full bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">UNLOCKED</span>}
                </div>
                <p className="mt-0.5 text-xs text-[var(--text-dim)]">{a.description}</p>
                {!a.unlocked && (
                  <div className="mt-3">
                    <ProgressBar value={a.progress} tone="warn" />
                    <p className="mt-1 text-[10px] text-[var(--text-faint)]">{Math.round(a.progress * 100)}% complete</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
