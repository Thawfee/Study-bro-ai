"use client";

import { useStoredState } from "@/hooks/useStoredState";
import { Palette, Bell, ScanFace, ShieldCheck, Trash2, UserCog } from "lucide-react";
import { useWorkspace } from "@/lib/store/workspace-store";
import { useStudyBro } from "@/lib/store/studybro-store";
import { PageHeader } from "@/components/ui/common";
import { Button } from "@/components/ui/Button";
import { Toggle } from "@/components/ui/Toggle";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import { SettingsForm } from "@/components/settings/SettingsForm";
import type { LucideIcon } from "lucide-react";

const PREF_KEY = "studybro.prefs.v1";
interface Prefs { reminders: boolean; sounds: boolean; broMessages: boolean; }
const DEFAULT_PREFS: Prefs = { reminders: true, sounds: true, broMessages: true };

function Section({ icon: Icon, title, desc, children }: { icon: LucideIcon; title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="card p-5">
      <div className="mb-4 flex items-start gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-violet-400/30 bg-violet-500/10 text-violet-300">
          <Icon size={17} />
        </span>
        <div>
          <h3 className="text-sm font-semibold text-[var(--text)]">{title}</h3>
          <p className="text-xs text-[var(--text-dim)]">{desc}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

function Row({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 border-t border-[var(--border)] py-3 first:border-t-0">
      <div>
        <p className="text-sm font-medium text-[var(--text)]">{title}</p>
        <p className="text-xs text-[var(--text-dim)]">{desc}</p>
      </div>
      {children}
    </div>
  );
}

function Threshold({ label, value, min, max, onChange }: { label: string; value: number; min: number; max: number; onChange: (value: number) => void }) {
  return (
    <label className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/70 p-3">
      <div className="mb-2 flex items-center justify-between gap-3"><span className="text-xs text-[var(--text-dim)]">{label}</span><span className="text-xs font-semibold tabular-nums text-[var(--text)]">{(value / 1000).toFixed(1)}s</span></div>
      <input type="range" min={min} max={max} step={500} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-violet-500" />
    </label>
  );
}

export default function SettingsPage() {
  const { profile } = useWorkspace();
  const { settings, updateSettings } = useStudyBro();
  const [storedPrefs, setStoredPrefs] = useStoredState<Partial<Prefs>>(PREF_KEY, DEFAULT_PREFS);
  const prefs: Prefs = { ...DEFAULT_PREFS, ...storedPrefs };
  const setPref = (patch: Partial<Prefs>) => setStoredPrefs((p) => ({ ...DEFAULT_PREFS, ...p, ...patch }));

  const resetData = () => {
    if (!confirm("Reset all local StudyBro data (tasks, goals, notes, profile, settings)? This cannot be undone.")) return;
    try {
      localStorage.removeItem("studybro.workspace.v1");
      localStorage.removeItem("studybro.settings.v1");
      localStorage.removeItem("studybro.settings.v2");
      localStorage.removeItem(PREF_KEY);
      localStorage.removeItem("studybro.focus-baseline.v1");
      localStorage.removeItem("studybro.ai-test-lab.v1");
    } catch { /* ignore */ }
    location.reload();
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title="Settings" subtitle="Make StudyBro yours." />

      <Section icon={Palette} title="Appearance" desc="Choose how StudyBro looks.">
        <Row title="Theme" desc="Dark, light, or match your system.">
          <ThemeToggle />
        </Row>
      </Section>

      <Section icon={Bell} title="Notifications & Personality" desc="Control reminders and StudyBro's voice.">
        <Row title="Study reminders" desc="Nudge me to keep my streak alive.">
          <Toggle checked={prefs.reminders} onChange={(v) => setPref({ reminders: v })} label="Study reminders" />
        </Row>
        <Row title="Sound effects" desc="Play a chime when a session ends.">
          <Toggle checked={prefs.sounds} onChange={(v) => setPref({ sounds: v })} label="Sound effects" />
        </Row>
        <Row title="Bro messages" desc="Let StudyBro talk to you like a friend. 😎">
          <Toggle checked={prefs.broMessages} onChange={(v) => setPref({ broMessages: v })} label="Bro messages" />
        </Row>
      </Section>

      <Section icon={ScanFace} title="AI Monitoring" desc="Real in-browser computer vision runs on the Focus Monitor.">
        <Row title="Show face landmarks" desc="Draw the clean eye / brow / face overlay on the camera.">
          <Toggle checked={settings.showLandmarks} onChange={(v) => updateSettings({ showLandmarks: v })} label="Show face landmarks" />
        </Row>
        <div className="border-t border-[var(--border)] pt-3">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--text-faint)]">Adaptive alert thresholds</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <Threshold label="Drowsiness" value={settings.drowsinessThresholdMs} min={5200} max={10000} onChange={(v) => updateSettings({ drowsinessThresholdMs: v })} />
            <Threshold label="Distraction" value={settings.distractionThresholdMs} min={3200} max={8000} onChange={(v) => updateSettings({ distractionThresholdMs: v })} />
            <Threshold label="Phone" value={settings.phoneThresholdMs} min={1900} max={8000} onChange={(v) => updateSettings({ phoneThresholdMs: v })} />
            <Threshold label="Away" value={settings.awayThresholdMs} min={6000} max={12000} onChange={(v) => updateSettings({ awayThresholdMs: v })} />
            <Threshold label="Posture" value={settings.postureThresholdMs} min={4500} max={8000} onChange={(v) => updateSettings({ postureThresholdMs: v })} />
          </div>
          <p className="mt-3 text-xs leading-relaxed text-[var(--text-dim)]">
            Expo Accuracy mode enforces conservative minimum confirmation times and person-specific calibration. These settings can make alerts slower, but not less stable than the accuracy floor. They are behavioral thresholds, not medical thresholds. Camera frames are analyzed in the browser and are not recorded by default.
          </p>
        </div>
      </Section>

      <Section icon={ShieldCheck} title="Video Alerts" desc="Tune StudyBro's video interventions.">
        <SettingsForm />
      </Section>

      <Section icon={UserCog} title="Account" desc="Your local StudyBro account.">
        <Row title="Signed in as" desc={profile.email}>
          <Button href="/profile" variant="secondary" size="sm">Manage</Button>
        </Row>
        <Row title="Reset local data" desc="Clear tasks, goals, notes, profile & settings from this browser.">
          <Button variant="danger" size="sm" icon={Trash2} onClick={resetData}>Reset</Button>
        </Row>
      </Section>
    </div>
  );
}
