"use client";

import Link from "next/link";
import { ArrowLeft, BrainCircuit, ShieldCheck, Sparkles } from "lucide-react";
import { LiveAIMonitor } from "@/components/camera/LiveAIMonitor";
import { FocusTimelinePanel } from "@/components/dashboard/FocusTimelinePanel";
import { AIExplanationPanel } from "@/components/dashboard/AIExplanationPanel";
import { JudgeDemoPanel } from "@/components/dashboard/JudgeDemoPanel";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatDuration } from "@/lib/utils";

function deriveState(score: number, d: ReturnType<typeof useStudyBro>["detections"]) {
  if (d.presence.status === "AWAY") return ["AWAY", "⚪", "text-slate-300"] as const;
  if (d.phone.status === "DETECTED" || d.drowsiness.status === "CRITICAL") return ["INTERVENTION REQUIRED", "🔴", "text-rose-300"] as const;
  if (d.drowsiness.status === "WARNING") return ["FATIGUED", "🟠", "text-amber-300"] as const;
  if (d.gaze.status !== "FOCUSED" || d.posture.status !== "GOOD") return ["DISTRACTED", "🟡", "text-amber-300"] as const;
  return score >= 88 ? ["DEEP FOCUS", "🟢", "text-emerald-300"] as const : ["FOCUSED", "🔵", "text-cyan-300"] as const;
}

export default function ExpoPage() {
  const { focus, detections, activeAlert, recoveries, session } = useStudyBro();
  const [state, emoji, tone] = deriveState(focus.score, detections);
  const avgRecovery = recoveries.length ? recoveries.reduce((a,r)=>a+r.durationMs,0)/recoveries.length : 0;

  return (
    <div className="min-h-screen bg-[var(--bg)] p-3 sm:p-4">
      <div className="mx-auto max-w-[1600px] space-y-3">
        <header className="flex flex-wrap items-center justify-between gap-3 rounded-[1.4rem] border border-[var(--border)] bg-[var(--surface)]/80 px-4 py-3 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <Link href="/focus" className="grid h-9 w-9 place-items-center rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:text-[var(--text)]" aria-label="Exit Expo Mode"><ArrowLeft size={16}/></Link>
            <div><div className="inline-flex items-center gap-2 text-violet-200"><Sparkles size={14}/><span className="text-[11px] font-semibold uppercase tracking-[0.18em]">Expo Mode</span></div><h1 className="text-lg font-bold text-[var(--text)]">StudyBro AI — Your AI Study Guardian</h1></div>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs"><span className="rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-emerald-200"><ShieldCheck size={12} className="mr-1 inline"/> Privacy-first</span><span className="rounded-full border border-violet-400/20 bg-violet-500/10 px-3 py-1 text-violet-200"><BrainCircuit size={12} className="mr-1 inline"/> Focus Fusion Engine</span></div>
        </header>

        <div className="grid gap-3 2xl:grid-cols-[1.45fr_0.75fr]">
          <LiveAIMonitor className="min-h-0" />
          <div className="grid gap-3 md:grid-cols-2 2xl:grid-cols-1">
            <div className="card p-5 text-center">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--text-faint)]">Current Study State</p>
              <p className="mt-2 text-6xl font-bold tabular-nums text-[var(--text)]">{focus.score}</p>
              <p className={`mt-2 text-lg font-semibold ${tone}`}>{emoji} {state}</p>
              <div className="mt-4 grid grid-cols-2 gap-2 text-left">
                <Metric label="Eyes" value={detections.drowsiness.eyeState.toUpperCase()} />
                <Metric label="Gaze" value={detections.gaze.direction} />
                <Metric label="Phone" value={detections.phone.status === "DETECTED" ? "DETECTED" : "NONE"} />
                <Metric label="Posture" value={detections.posture.status} />
                <Metric label="Presence" value={detections.presence.status} />
                <Metric label="Fatigue" value={detections.drowsiness.status} />
              </div>
            </div>
            <div className="card p-5">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--text-faint)]">Intervention Intelligence</p>
              <div className="mt-3 space-y-2">
                <Row label="Status" value={activeAlert ? "INTERVENING" : "MONITORING"}/>
                <Row label="Action" value={activeAlert ? activeAlert.title : "No active intervention"}/>
                <Row label="Study time" value={formatDuration(session.metrics.studyTimeMs)}/>
                <Row label="Recovery" value={recoveries.length ? `${Math.max(1,Math.round(avgRecovery/1000))} sec avg` : "Collecting"}/>
              </div>
            </div>
          </div>
        </div>

        <JudgeDemoPanel compact />

        <div className="grid gap-3 xl:grid-cols-2">
          <FocusTimelinePanel limit={5}/>
          <AIExplanationPanel/>
        </div>
      </div>
    </div>
  );
}

function Metric({label,value}:{label:string;value:string}) { return <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)]/70 p-2.5"><p className="text-[9px] uppercase tracking-wider text-[var(--text-faint)]">{label}</p><p className="mt-1 text-xs font-semibold text-[var(--text)]">{value}</p></div>; }
function Row({label,value}:{label:string;value:string}) { return <div className="flex items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)]/70 px-3 py-2.5 text-sm"><span className="text-[var(--text-dim)]">{label}</span><span className="max-w-[65%] text-right font-medium text-[var(--text)]">{value}</span></div>; }
