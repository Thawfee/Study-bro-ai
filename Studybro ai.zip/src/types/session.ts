/* ============================================================
   StudyBro AI — Study session types
   ============================================================ */

export interface StudyMetrics {
  studyTimeMs: number;
  focusedTimeMs: number;
  distractionTimeMs: number;
  phoneUsageMs: number;
  drowsinessMs: number;
  awayMs: number;
  /** Rolling 0–100 posture quality score. */
  postureScore: number;
}

export interface StudySession {
  /** Set when monitoring actually begins (live camera or a demo run) — not on page load. */
  startedAt: number | null;
  /** What is driving this session. Only "live" sessions feed the personal baseline. */
  source: "live" | "demo" | null;
  metrics: StudyMetrics;
}

export function emptyMetrics(): StudyMetrics {
  return {
    studyTimeMs: 0,
    focusedTimeMs: 0,
    distractionTimeMs: 0,
    phoneUsageMs: 0,
    drowsinessMs: 0,
    awayMs: 0,
    postureScore: 100,
  };
}

/** A measured recovery after an intervention ends. */
export interface RecoveryRecord {
  id: string;
  type: "drowsiness" | "phone" | "distraction" | "posture" | "away";
  startedAt: number;
  recoveredAt: number;
  durationMs: number;
}
