/* ============================================================
   StudyBro AI — Alert & event types
   ============================================================ */

import type { DetectionType, Severity } from "./ai";

/** An entry in the "Recent AI Events" feed. */
export interface AlertEvent {
  id: string;
  type: DetectionType | "system";
  icon: string; // emoji
  message: string;
  severity: Severity;
  timestamp: number;
}

/** The active full-screen video alert (null when nothing is showing). */
export interface VideoAlert {
  id: string;
  type: DetectionType;
  title: string;
  message: string;
  /** Resolved URL of the video to play (may 404 → fallback handled in UI). */
  videoUrl: string;
  createdAt: number;
}

/** Lightweight, non-blocking toast (used for minor warnings / cooldowns). */
export interface ToastMessage {
  id: string;
  type: DetectionType | "system";
  icon: string;
  title: string;
  message: string;
  severity: Severity;
  createdAt: number;
}

/** Static configuration for one detection's video alert. */
export interface VideoAlertConfig {
  type: DetectionType;
  title: string;
  message: string;
  /** Ordered list — architecture supports multiple videos per type. */
  videos: string[];
  fallbackIcon: string;
}

/** User-tunable behavior for the video alert system (from /settings). */
export interface VideoSettings {
  videoAlertsEnabled: boolean;
  autoPlay: boolean;
  autoClose: boolean;
  loop: boolean;
  /** Cooldown between video popups, in milliseconds. */
  cooldownMs: number;
  /** 0–100 */
  volume: number;
  /** Draw the minimal facial-landmark overlay on the camera feed. */
  showLandmarks: boolean;
  /** Live confirmation thresholds. */
  drowsinessThresholdMs: number;
  distractionThresholdMs: number;
  phoneThresholdMs: number;
  awayThresholdMs: number;
  postureThresholdMs: number;
}
