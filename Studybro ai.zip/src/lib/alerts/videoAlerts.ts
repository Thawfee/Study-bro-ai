/* ============================================================
   Centralized video-alert configuration (StudyBro personality).

   Video mapping (3 custom clips):
     • Drowsiness → sleep-1.mp4 OR sleep-2.mp4 (randomly chosen)
     • Phone / Distraction / Posture / Away → general-alert.mp4

   To change a video: drop a new file into /public/videos/ and update
   the `videos` array. Missing files degrade to a standard notification.
   ============================================================ */

import type { DetectionType } from "@/types/ai";
import type { VideoAlertConfig, VideoSettings } from "@/types/alerts";

export const VIDEO_ALERT_COOLDOWN = 30000;

export const DEFAULT_VIDEO_SETTINGS: VideoSettings = {
  videoAlertsEnabled: true,
  autoPlay: true,
  autoClose: false,
  loop: true,
  cooldownMs: VIDEO_ALERT_COOLDOWN,
  volume: 80,
  showLandmarks: true,
  drowsinessThresholdMs: 5200,
  distractionThresholdMs: 3200,
  phoneThresholdMs: 1900,
  awayThresholdMs: 6000,
  postureThresholdMs: 4500,
};

const GENERAL = "/videos/general-alert.mp4";

export const VIDEO_ALERTS: Record<DetectionType, VideoAlertConfig> = {
  drowsiness: {
    type: "drowsiness",
    title: "😴 WAKE UP, BRO!",
    message: "Bro, wake up — you're studying in your dreams. Let's go! 😴",
    videos: ["/videos/sleep-1.mp4", "/videos/sleep-2.mp4"],
    fallbackIcon: "😴",
  },
  phone: {
    type: "phone",
    title: "📱 PHONE, REALLY?",
    message: "Bro… Instagram can wait. Your future can't. 😂",
    videos: [GENERAL],
    fallbackIcon: "📱",
  },
  distraction: {
    type: "distraction",
    title: "👀 EYES ON THE MISSION",
    message: "Your focus wandered off, Bro. Come back to the books. 👀",
    videos: [GENERAL],
    fallbackIcon: "👀",
  },
  posture: {
    type: "posture",
    title: "🪑 SIT UP, BRO",
    message: "Straighten up, Bro. Your back will thank you later. 🪑",
    videos: [GENERAL],
    fallbackIcon: "🪑",
  },
  away: {
    type: "away",
    title: "🚶 WHERE'D YOU GO, BRO?",
    message: "Your study session is waiting for you, Bro! 🚶",
    videos: [GENERAL],
    fallbackIcon: "🚶",
  },
};

/** Choose a video for a detection (random pick supports multiple clips). */
export function pickVideo(type: DetectionType): string | null {
  const list = VIDEO_ALERTS[type].videos;
  if (!list || list.length === 0) return null;
  if (list.length === 1) return list[0];
  return list[Math.floor(Math.random() * list.length)];
}
