"use client";

/* ============================================================
   StudyBroStore — the central brain.

   Holds ALL live state (detections, focus score, events, alerts,
   toasts, session metrics, settings) and exposes actions. Detection
   logic (lib/ai) and anti-spam logic (lib/alerts) are kept separate;
   this store just wires them together and runs the 1s "engine tick"
   that behaves like the future streaming AI backend.
   ============================================================ */

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
} from "react";

import type {
  DetectionSnapshot,
  DetectionType,
  FocusState,
} from "@/types/ai";
import type {
  AlertEvent,
  ToastMessage,
  VideoAlert,
  VideoSettings,
} from "@/types/alerts";
import type { RecoveryRecord, StudySession } from "@/types/session";
import { emptyMetrics } from "@/types/session";

import { normalDrowsiness } from "@/lib/ai/drowsiness";
import { normalPhone } from "@/lib/ai/phone";
import { normalGaze } from "@/lib/ai/gaze";
import { normalPosture } from "@/lib/ai/posture";
import { normalPresence } from "@/lib/ai/presence";
import {
  clampScore,
  deductionFor,
  FACTOR_LABELS,
  focusStatusFromScore,
  REWARD_MILESTONES,
} from "@/lib/ai/focus-engine";
import {
  simulateDetection,
  type AIExplanation,
  type DemoDetectionOutput,
} from "@/lib/ai/demo-engine";
import { evaluateAlert, type CooldownMap } from "@/lib/alerts/alertManager";
import {
  DEFAULT_VIDEO_SETTINGS,
  pickVideo,
  VIDEO_ALERTS,
} from "@/lib/alerts/videoAlerts";
import { uid } from "@/lib/utils";

export const DEMO_MODE = true;
const RECOVERY_MS = 7000; // how long a triggered state lingers before auto-recovery
const MAX_EVENTS = 60;
const SETTINGS_KEY = "studybro.settings.v2";

/* ------------------------------- State -------------------------------- */

/** "demo" = simulated triggers. "live" = real in-browser AI is driving detections. */
export type EngineMode = "demo" | "live";

interface StoreState {
  monitoring: boolean;
  mode: EngineMode;
  now: number;
  detections: DetectionSnapshot;
  focus: FocusState;
  events: AlertEvent[];
  toasts: ToastMessage[];
  activeAlert: VideoAlert | null;
  explanation: AIExplanation | null;
  settings: VideoSettings;
  session: StudySession;
  recoveries: RecoveryRecord[];
  cooldowns: CooldownMap;
  rewardsGranted: number[]; // minute milestones already awarded
}

function freshDetections(): DetectionSnapshot {
  return {
    drowsiness: normalDrowsiness(),
    phone: normalPhone(),
    gaze: normalGaze(),
    posture: normalPosture(),
    presence: normalPresence(),
  };
}

function freshFocus(): FocusState {
  return { score: 100, status: "Focused", factors: [] };
}

function initialState(): StoreState {
  return {
    monitoring: true,
    mode: "demo",
    now: 0,
    detections: freshDetections(),
    focus: freshFocus(),
    events: [],
    toasts: [],
    activeAlert: null,
    explanation: null,
    settings: DEFAULT_VIDEO_SETTINGS,
    session: { startedAt: null, source: null, metrics: emptyMetrics() },
    recoveries: [],
    cooldowns: {},
    rewardsGranted: [],
  };
}

/* ------------------------------ Actions ------------------------------- */

type Action =
  | { kind: "TRIGGER"; type: DetectionType; now: number }
  | { kind: "INGEST"; output: DemoDetectionOutput; now: number }
  | { kind: "LIVE_UPDATE"; patch: Partial<DetectionSnapshot>; now: number }
  | { kind: "PUSH_EVENT"; icon: string; message: string; now: number }
  | { kind: "SET_MODE"; mode: EngineMode; now: number }
  | { kind: "TICK"; now: number; dt: number }
  | { kind: "CLOSE_ALERT" }
  | { kind: "DISMISS_TOAST"; id: string }
  | { kind: "SET_MONITORING"; value: boolean }
  | { kind: "UPDATE_SETTINGS"; patch: Partial<VideoSettings> }
  | { kind: "HYDRATE_SETTINGS"; settings: VideoSettings }
  | { kind: "RESET" };

/* ------------------------------ Helpers ------------------------------- */

function pushEvent(events: AlertEvent[], ev: AlertEvent): AlertEvent[] {
  return [ev, ...events].slice(0, MAX_EVENTS);
}

function isActive(lastDetected: number | null, now: number): boolean {
  return lastDetected != null && now - lastDetected < RECOVERY_MS;
}

/**
 * Whether the live vision snapshot still supports the condition that opened
 * the intervention. This is deliberately based on the debounced/latched
 * detection state from useVisionEngine, not raw per-frame observations.
 */
function liveAlertConditionActive(type: DetectionType, d: DetectionSnapshot): boolean {
  switch (type) {
    case "phone":
      return d.phone.status === "DETECTED";
    case "drowsiness":
      return d.drowsiness.status === "CRITICAL";
    case "distraction":
      return d.gaze.status === "DISTRACTED";
    case "posture":
      return d.posture.status !== "GOOD";
    case "away":
      return d.presence.status === "AWAY";
  }
}

function recoveryMessage(type: DetectionType): { icon: string; message: string } {
  switch (type) {
    case "phone":
      return { icon: "✅", message: "Phone put away — intervention stopped" };
    case "drowsiness":
      return { icon: "👀", message: "Eyes open again — wake-up intervention stopped" };
    case "distraction":
      return { icon: "🎯", message: "Focus recovered — distraction intervention stopped" };
    case "posture":
      return { icon: "✅", message: "Posture recovered — intervention stopped" };
    case "away":
      return { icon: "👋", message: "Welcome back — intervention stopped" };
  }
}

function applyFactor(
  focus: FocusState,
  type: DetectionType | "reward",
  label: string,
  delta: number,
  now: number,
): FocusState {
  const score = clampScore(focus.score + delta);
  const factor = { id: uid("f"), type, label, delta, timestamp: now };
  return {
    score,
    status: focusStatusFromScore(score),
    factors: [factor, ...focus.factors].slice(0, 12),
  };
}

/**
 * The single "detection episode" pipeline, shared by simulated triggers
 * (demo) and real in-browser AI (live): apply patch → deduct score → log
 * event → set explanation → decide video alert vs. toast (anti-spam).
 */
function applyEpisode(
  state: StoreState,
  output: DemoDetectionOutput,
  now: number,
): StoreState {
  const { type } = output;
  const detections = { ...state.detections, ...output.patch };

  const focus = applyFactor(
    state.focus,
    type,
    FACTOR_LABELS[type],
    deductionFor(type),
    now,
  );

  const events = pushEvent(state.events, {
    id: uid("ev"),
    type,
    icon: output.event.icon,
    message: output.event.message,
    severity: output.event.severity,
    timestamp: now,
  });

  const decision = evaluateAlert({
    type,
    now,
    settings: state.settings,
    alertOpen: state.activeAlert != null,
    cooldowns: state.cooldowns,
  });

  let activeAlert = state.activeAlert;
  let cooldowns = state.cooldowns;
  let toasts = state.toasts;

  if (decision.fire === true) {
    const videoUrl = pickVideo(type) ?? "";
    const cfg = VIDEO_ALERTS[type];
    activeAlert = {
      id: uid("va"),
      type,
      title: cfg.title,
      message: cfg.message,
      videoUrl,
      createdAt: now,
    };
    cooldowns = { ...state.cooldowns, [type]: now };
  } else {
    const note =
      decision.reason === "cooldown"
        ? `On cooldown — ${Math.ceil(decision.remainingMs / 1000)}s left`
        : decision.reason === "already-open"
          ? "An alert is already open"
          : "Video alerts are off";
    toasts = [
      {
        id: uid("t"),
        type,
        icon: output.event.icon,
        title: output.event.message,
        message: note,
        severity: output.event.severity,
        createdAt: now,
      },
      ...state.toasts,
    ].slice(0, 4);
  }

  return {
    ...state,
    detections,
    focus,
    events,
    explanation: output.explanation,
    activeAlert,
    cooldowns,
    toasts,
    now,
  };
}

/** Start a fresh session (metrics + "session started" event). */
function beginSession(state: StoreState, source: "live" | "demo", now: number): StoreState {
  return {
    ...state,
    now,
    session: { startedAt: now, source, metrics: emptyMetrics() },
    rewardsGranted: [],
    events: pushEvent(state.events, {
      id: uid("ev"),
      type: "system",
      icon: "🟢",
      message: source === "live" ? "Live focus session started" : "Demo session started",
      severity: "normal",
      timestamp: now,
    }),
  };
}

/* ------------------------------ Reducer ------------------------------- */

function reducer(state: StoreState, action: Action): StoreState {
  switch (action.kind) {
    case "TRIGGER": {
      const { type, now } = action;
      // A simulated trigger starts a demo session if nothing is running yet.
      const base = state.session.startedAt == null ? beginSession(state, "demo", now) : state;
      const next = applyEpisode(base, simulateDetection(type, now), now);
      return { ...next, monitoring: true };
    }

    case "INGEST": {
      // Real AI reported a detection episode — same pipeline as demo.
      // While monitoring is paused, detections must not score or alert.
      if (!state.monitoring) return state;
      return applyEpisode(state, action.output, action.now);
    }

    case "LIVE_UPDATE": {
      // Continuous live detection snapshot from the vision engine.
      // No scoring here. It also owns recovery of a live intervention: once
      // the debounced condition clears, stop/unmount the video immediately.
      const detections = { ...state.detections, ...action.patch };
      let activeAlert = state.activeAlert;
      let events = state.events;
      let recoveries = state.recoveries;

      if (
        state.mode === "live" &&
        activeAlert &&
        !liveAlertConditionActive(activeAlert.type, detections)
      ) {
        const recovered = recoveryMessage(activeAlert.type);
        const durationMs = Math.max(0, action.now - activeAlert.createdAt);
        recoveries = [
          {
            id: uid("rec"),
            type: activeAlert.type,
            startedAt: activeAlert.createdAt,
            recoveredAt: action.now,
            durationMs,
          },
          ...state.recoveries,
        ].slice(0, 30);
        activeAlert = null;
        events = pushEvent(events, {
          id: uid("ev"),
          type: "system",
          icon: recovered.icon,
          message: `${recovered.message} · recovered in ${Math.max(1, Math.round(durationMs / 1000))}s`,
          severity: "normal",
          timestamp: action.now,
        });
      }

      return {
        ...state,
        now: action.now,
        detections,
        activeAlert,
        events,
        recoveries,
      };
    }

    case "PUSH_EVENT": {
      return {
        ...state,
        events: pushEvent(state.events, {
          id: uid("ev"),
          type: "system",
          icon: action.icon,
          message: action.message,
          severity: "normal",
          timestamp: action.now,
        }),
      };
    }

    case "SET_MODE": {
      // Going live starts a real session (a leftover demo session is replaced,
      // so simulated numbers never mix with live measurements).
      if (action.mode === "live" && state.session.source !== "live") {
        return { ...beginSession(state, "live", action.now), mode: "live" };
      }
      return { ...state, mode: action.mode };
    }

    case "TICK": {
      const { now, dt } = action;
      // Only accrue time while something is really being monitored:
      // a live camera session with the camera on, or a running demo session.
      // Having the app open with the camera off is NOT study time.
      const tracking =
        state.session.startedAt != null &&
        ((state.session.source === "live" && state.mode === "live") ||
          (state.session.source === "demo" && state.mode === "demo"));
      if (!state.monitoring || !tracking) {
        return { ...state, now };
      }

      const d = state.detections;
      let events = state.events;
      let focus = state.focus;

      // In LIVE mode the vision engine owns the detection snapshot
      // (recovery + durations). In DEMO mode the tick simulates them.
      const detections: DetectionSnapshot = { ...d };
      if (state.mode === "demo") {
        // --- auto-recovery of lingering states ---
        if (d.drowsiness.lastDetected && !isActive(d.drowsiness.lastDetected, now)) {
          detections.drowsiness = normalDrowsiness();
        }
        if (d.phone.lastDetected && !isActive(d.phone.lastDetected, now)) {
          detections.phone = normalPhone();
        }
        if (d.gaze.lastDetected && !isActive(d.gaze.lastDetected, now)) {
          detections.gaze = normalGaze();
        }
        if (d.posture.lastDetected && !isActive(d.posture.lastDetected, now)) {
          detections.posture = normalPosture();
        }
        if (
          d.presence.status === "AWAY" &&
          d.presence.lastDetected &&
          !isActive(d.presence.lastDetected, now)
        ) {
          detections.presence = normalPresence();
          events = pushEvent(events, {
            id: uid("ev"),
            type: "system",
            icon: "👋",
            message: "Welcome back, Bro! 👋",
            severity: "normal",
            timestamp: now,
          });
        }
      }

      // --- accrue durations on active problems ---
      // Live mode: use the vision engine's current confirmed state, so time
      // stops counting the moment the student recovers. Demo mode keeps the
      // simulated linger window.
      const live = state.mode === "live";
      const drowsyActive = live
        ? detections.drowsiness.status === "CRITICAL"
        : isActive(detections.drowsiness.lastDetected, now);
      const phoneActive = live
        ? detections.phone.status === "DETECTED"
        : isActive(detections.phone.lastDetected, now);
      const gazeActive = live
        ? detections.gaze.status === "DISTRACTED"
        : isActive(detections.gaze.lastDetected, now);
      const awayActive = detections.presence.status === "AWAY";
      const postureBad = live
        ? detections.posture.status === "BAD"
        : detections.posture.status !== "GOOD" && isActive(detections.posture.lastDetected, now);

      if (state.mode === "demo") {
        if (phoneActive) {
          detections.phone = {
            ...detections.phone,
            usageDurationMs: detections.phone.usageDurationMs + dt,
          };
        }
        if (gazeActive) {
          detections.gaze = {
            ...detections.gaze,
            distractionDurationMs: detections.gaze.distractionDurationMs + dt,
          };
        }
        if (awayActive) {
          detections.presence = {
            ...detections.presence,
            awayDurationMs: detections.presence.awayDurationMs + dt,
          };
        }
      }

      const anyProblem = drowsyActive || phoneActive || gazeActive || awayActive || postureBad;

      const m = { ...state.session.metrics };
      m.studyTimeMs += dt;
      if (drowsyActive) m.drowsinessMs += dt;
      if (phoneActive) m.phoneUsageMs += dt;
      if (gazeActive) m.distractionTimeMs += dt;
      if (awayActive) m.awayMs += dt;
      if (!anyProblem && detections.presence.status === "PRESENT") {
        m.focusedTimeMs += dt;
      }
      // posture score drifts down when bad, recovers when good
      m.postureScore = postureBad
        ? Math.max(40, m.postureScore - (dt / 1000) * 3)
        : Math.min(100, m.postureScore + (dt / 1000) * 1);

      // --- focused-time reward milestones ---
      const rewardsGranted = [...state.rewardsGranted];
      const focusedMin = m.focusedTimeMs / 60000;
      for (const ms of REWARD_MILESTONES) {
        if (focusedMin >= ms.minutes && !rewardsGranted.includes(ms.minutes)) {
          rewardsGranted.push(ms.minutes);
          focus = applyFactor(focus, "reward", ms.label, ms.points, now);
          events = pushEvent(events, {
            id: uid("ev"),
            type: "system",
            icon: "🏅",
            message: `Reward: ${ms.label} (+${ms.points})`,
            severity: "normal",
            timestamp: now,
          });
        }
      }

      return {
        ...state,
        now,
        detections,
        focus,
        events,
        rewardsGranted,
        session: { ...state.session, metrics: m },
      };
    }

    case "CLOSE_ALERT": {
      const closing = state.activeAlert;
      let detections = state.detections;
      let events = state.events;
      // "I'm Back" on the away alert implies the student returned.
      if (closing?.type === "away" && state.detections.presence.status === "AWAY") {
        detections = { ...state.detections, presence: normalPresence() };
        events = pushEvent(state.events, {
          id: uid("ev"),
          type: "system",
          icon: "👋",
          message: "Welcome back, Bro! 👋",
          severity: "normal",
          timestamp: state.now || Date.now(),
        });
      }
      return { ...state, activeAlert: null, detections, events };
    }

    case "DISMISS_TOAST":
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.id) };

    case "SET_MONITORING": {
      if (action.value) return { ...state, monitoring: true };
      // Pausing closes any open intervention; nothing new can fire while paused.
      return {
        ...state,
        monitoring: false,
        activeAlert: null,
        events: pushEvent(state.events, {
          id: uid("ev"),
          type: "system",
          icon: "⏸️",
          message: "Monitoring paused — detections will not alert or change your score",
          severity: "normal",
          timestamp: state.now || Date.now(),
        }),
      };
    }

    case "UPDATE_SETTINGS":
      return { ...state, settings: { ...state.settings, ...action.patch } };

    case "HYDRATE_SETTINGS":
      return { ...state, settings: action.settings };

    case "RESET": {
      const now = state.now || Date.now();
      return {
        ...state,
        detections: freshDetections(),
        focus: freshFocus(),
        events: [
          {
            id: uid("ev"),
            type: "system",
            icon: "🟢",
            message: state.mode === "live" ? "Live focus session restarted" : "Demo session started",
            severity: "normal",
            timestamp: now,
          },
        ],
        toasts: [],
        activeAlert: null,
        explanation: null,
        cooldowns: {},
        rewardsGranted: [],
        session: { startedAt: now, source: state.mode === "live" ? "live" : "demo", metrics: emptyMetrics() },
        recoveries: [],
      };
    }

    default:
      return state;
  }
}

/* ------------------------------ Context ------------------------------- */

interface StoreContextValue extends StoreState {
  demoMode: boolean;
  trigger: (type: DetectionType) => void;
  /** Real-AI: report a detection episode (score + event + alert). */
  ingest: (output: DemoDetectionOutput) => void;
  /** Real-AI: push the continuous live detection snapshot (no scoring). */
  liveUpdate: (patch: Partial<DetectionSnapshot>) => void;
  /** Push a plain system event (e.g. "Welcome back, Bro! 👋"). */
  pushSystemEvent: (icon: string, message: string) => void;
  setMode: (mode: EngineMode) => void;
  closeAlert: () => void;
  dismissToast: (id: string) => void;
  setMonitoring: (value: boolean) => void;
  updateSettings: (patch: Partial<VideoSettings>) => void;
  reset: () => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function StudyBroProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, initialState);
  const lastTick = useRef<number>(0);
  const started = useRef(false);

  // Start the session + load persisted settings on mount (client only).
  // Guarded so React StrictMode's double-invoke doesn't start twice.
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const now = Date.now();
    lastTick.current = now;
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<VideoSettings>;
        dispatch({
          kind: "HYDRATE_SETTINGS",
          settings: { ...DEFAULT_VIDEO_SETTINGS, ...parsed },
        });
      }
    } catch {
      /* ignore corrupt/blocked storage */
    }
    // No session starts here: a session begins only when live monitoring or
    // a demo actually starts, so idle app time is never counted as study.
  }, []);

  // Persist settings whenever they change.
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(state.settings));
    } catch {
      /* ignore */
    }
  }, [state.settings]);

  // Engine tick — behaves like a streaming AI backend pushing updates.
  useEffect(() => {
    const id = setInterval(() => {
      const now = Date.now();
      const dt = lastTick.current ? now - lastTick.current : 1000;
      lastTick.current = now;
      dispatch({ kind: "TICK", now, dt });
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const trigger = useCallback((type: DetectionType) => {
    dispatch({ kind: "TRIGGER", type, now: Date.now() });
  }, []);
  const ingest = useCallback((output: DemoDetectionOutput) => {
    dispatch({ kind: "INGEST", output, now: Date.now() });
  }, []);
  const liveUpdate = useCallback((patch: Partial<DetectionSnapshot>) => {
    dispatch({ kind: "LIVE_UPDATE", patch, now: Date.now() });
  }, []);
  const pushSystemEvent = useCallback((icon: string, message: string) => {
    dispatch({ kind: "PUSH_EVENT", icon, message, now: Date.now() });
  }, []);
  const setMode = useCallback((mode: EngineMode) => dispatch({ kind: "SET_MODE", mode, now: Date.now() }), []);
  const closeAlert = useCallback(() => dispatch({ kind: "CLOSE_ALERT" }), []);
  const dismissToast = useCallback((id: string) => dispatch({ kind: "DISMISS_TOAST", id }), []);
  const setMonitoring = useCallback((value: boolean) => dispatch({ kind: "SET_MONITORING", value }), []);
  const updateSettings = useCallback(
    (patch: Partial<VideoSettings>) => dispatch({ kind: "UPDATE_SETTINGS", patch }),
    [],
  );
  const reset = useCallback(() => dispatch({ kind: "RESET" }), []);

  const value = useMemo<StoreContextValue>(
    () => ({
      ...state,
      demoMode: DEMO_MODE,
      trigger,
      ingest,
      liveUpdate,
      pushSystemEvent,
      setMode,
      closeAlert,
      dismissToast,
      setMonitoring,
      updateSettings,
      reset,
    }),
    [state, trigger, ingest, liveUpdate, pushSystemEvent, setMode, closeAlert, dismissToast, setMonitoring, updateSettings, reset],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStudyBro(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) {
    throw new Error("useStudyBro must be used within <StudyBroProvider>");
  }
  return ctx;
}
