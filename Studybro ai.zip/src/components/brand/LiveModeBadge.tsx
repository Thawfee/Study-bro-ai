"use client";

import { FlaskConical, ScanEye } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { cn } from "@/lib/utils";

/** Honest mode indicator: DEMO MODE vs. real AI MONITORING ACTIVE. */
export function LiveModeBadge({ className }: { className?: string }) {
  const { mode } = useStudyBro();
  const live = mode === "live";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider",
        live
          ? "border-emerald-400/40 bg-emerald-500/10 text-emerald-300"
          : "border-amber-400/40 bg-amber-500/10 text-amber-300",
        className,
      )}
      title={
        live
          ? "Real in-browser AI (MediaPipe + COCO-SSD) is analyzing your webcam."
          : "Detections are simulated. Enable the camera for real AI detection."
      }
    >
      {live ? (
        <>
          <ScanEye size={13} /> AI Monitoring Active
        </>
      ) : (
        <>
          <FlaskConical size={13} /> Demo Mode
        </>
      )}
    </span>
  );
}
