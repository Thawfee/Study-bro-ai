import { FlaskConical } from "lucide-react";
import { cn } from "@/lib/utils";

/** Prominent, honest "this is simulated" indicator. */
export function DemoModeBadge({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-amber-400/40 bg-amber-500/10 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-amber-300",
        className,
      )}
      title="Detections are simulated. Real Python/OpenCV AI backend integrates later."
    >
      <FlaskConical size={13} />
      Demo Mode
    </span>
  );
}
