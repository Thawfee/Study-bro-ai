"use client";

import { useEffect, useState } from "react";
import { Menu, X, Search, Sparkles } from "lucide-react";
import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/navigation/Sidebar";
import { BottomNav } from "@/components/navigation/BottomNav";
import { SearchModal } from "@/components/navigation/SearchModal";
import { MonitoringToggle } from "@/components/layout/MonitoringToggle";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import { Logo } from "@/components/brand/Logo";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState(false);
  const pathname = usePathname();
  const isExpo = pathname === "/expo";

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearch((s) => !s);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  if (isExpo) return <div className="min-h-screen">{children}</div>;

  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[18rem] border-r border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-elev)_72%,transparent)] backdrop-blur-2xl lg:block">
        <Sidebar />
      </aside>

      <div className={cn("fixed inset-0 z-50 lg:hidden transition-opacity", open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0")}>
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
        <aside className={cn("absolute inset-y-0 left-0 w-72 max-w-[85vw] border-r border-[var(--border)] bg-[var(--bg-elev)]/95 backdrop-blur-2xl transition-transform duration-300", open ? "translate-x-0" : "-translate-x-full")}>
          <button onClick={() => setOpen(false)} aria-label="Close menu" className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)]">
            <X size={18} />
          </button>
          <Sidebar onNavigate={() => setOpen(false)} />
        </aside>
      </div>

      <div className="lg:pl-[18rem]">
        <header className="sticky top-0 z-30 border-b border-[var(--border)] bg-[color-mix(in_srgb,var(--bg)_74%,transparent)] backdrop-blur-2xl">
          <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-6">
            <div className="flex items-center gap-3">
              <button onClick={() => setOpen(true)} aria-label="Open menu" className="grid h-9 w-9 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] lg:hidden">
                <Menu size={18} />
              </button>
              <div className="lg:hidden">
                <Logo withText={false} size="sm" />
              </div>
              <button onClick={() => setSearch(true)} className="hidden items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text-faint)] transition-colors hover:text-[var(--text-dim)] sm:flex">
                <Search size={15} />
                <span>Search…</span>
                <kbd className="ml-6 rounded border border-[var(--border)] px-1.5 py-0.5 text-[10px]">⌘K</kbd>
              </button>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setSearch(true)} aria-label="Search" className="grid h-9 w-9 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] sm:hidden">
                <Search size={17} />
              </button>
              <MonitoringToggle />
              <ThemeToggle className="hidden sm:inline-flex" />
            </div>
          </div>
          <div className="hidden items-center justify-between border-t border-[var(--border)] px-6 py-2.5 text-xs text-[var(--text-dim)] sm:flex">
            <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-500/10 px-3 py-1 text-violet-200">
              <Sparkles size={12} /> Premium AI Study Guardian Workspace
            </div>
            <span>Focus Fusion • Intervention Engine • Recovery Analytics</span>
          </div>
        </header>

        <main className="mx-auto max-w-[92rem] px-4 py-6 pb-24 sm:px-6 sm:py-8 lg:pb-8">{children}</main>
      </div>

      <BottomNav />
      <SearchModal open={search} onClose={() => setSearch(false)} />
    </div>
  );
}
