"use client";

import { Activity, Pause } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { cn } from "@/lib/utils";

export function MonitoringToggle() {
  const { monitoring, setMonitoring, mode } = useStudyBro();
  const activeLabel = mode === "live" ? "AI Monitoring Active" : "Demo Monitoring";
  return (
    <button
      onClick={() => setMonitoring(!monitoring)}
      aria-pressed={monitoring}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors",
        monitoring
          ? "border-emerald-400/30 bg-emerald-500/10 text-emerald-300"
          : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:bg-[var(--surface-2)]",
      )}
    >
      {monitoring ? (
        <>
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          {activeLabel}
        </>
      ) : (
        <>
          <Pause size={12} /> Monitoring Paused
        </>
      )}
      <Activity size={13} className="opacity-70" />
    </button>
  );
}
