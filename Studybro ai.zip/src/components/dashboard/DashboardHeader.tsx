"use client";

import { useSyncExternalStore } from "react";
import { Play } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { LiveModeBadge } from "@/components/brand/LiveModeBadge";

const noopSubscribe = () => () => {};

export function DashboardHeader() {
  // Client-only date (empty during the static server render → no hydration mismatch).
  const dateStr = useSyncExternalStore(
    noopSubscribe,
    () => new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }),
    () => "",
  );

  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-xs font-medium uppercase tracking-wider text-[var(--text-faint)]">{dateStr || " "}</p>
        <h1 className="mt-1 text-2xl font-bold tracking-tight text-[var(--text)] sm:text-3xl">
          Hey, Bro! 👋
        </h1>
        <p className="mt-1 text-sm text-[var(--text-dim)]">Ready to crush today&apos;s study goals?</p>
      </div>
      <div className="flex items-center gap-2">
        <LiveModeBadge />
        <Button href="/focus" icon={Play}>Start Focus Session</Button>
      </div>
    </div>
  );
}
