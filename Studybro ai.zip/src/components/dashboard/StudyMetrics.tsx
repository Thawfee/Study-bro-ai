"use client";

import {
  Clock,
  Target,
  EyeOff,
  Smartphone,
  Moon,
  DoorOpen,
  Armchair,
  type LucideIcon,
} from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatDuration } from "@/lib/utils";
import { cn } from "@/lib/utils";
import type { Tone } from "@/lib/tone";
import { TONE } from "@/lib/tone";

function MetricCard({
  icon: Icon,
  label,
  value,
  tone = "neutral",
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  tone?: Tone;
}) {
  const t = TONE[tone];
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2">
        <span className={cn("grid h-8 w-8 place-items-center rounded-lg border", t.bg, t.border)}>
          <Icon size={16} className={t.text} />
        </span>
        <span className="text-xs text-[var(--text-dim)]">{label}</span>
      </div>
      <p className="mt-3 text-2xl font-bold tabular-nums text-[var(--text)]">{value}</p>
    </div>
  );
}

export function StudyMetrics() {
  const { session } = useStudyBro();
  const m = session.metrics;

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
      <MetricCard icon={Clock} label="Study Time" value={formatDuration(m.studyTimeMs)} tone="brand" />
      <MetricCard icon={Target} label="Focused Time" value={formatDuration(m.focusedTimeMs)} tone="good" />
      <MetricCard icon={EyeOff} label="Distraction" value={formatDuration(m.distractionTimeMs)} tone="warn" />
      <MetricCard icon={Smartphone} label="Phone Usage" value={formatDuration(m.phoneUsageMs)} tone="bad" />
      <MetricCard icon={Moon} label="Drowsiness" value={formatDuration(m.drowsinessMs)} tone="warn" />
      <MetricCard icon={DoorOpen} label="Away Time" value={formatDuration(m.awayMs)} tone="bad" />
      <MetricCard icon={Armchair} label="Posture Score" value={`${Math.round(m.postureScore)}%`} tone="good" />
    </div>
  );
}
