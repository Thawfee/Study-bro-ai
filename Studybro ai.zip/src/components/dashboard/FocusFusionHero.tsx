"use client";

import {
  Activity,
  AlertTriangle,
  BrainCircuit,
  Eye,
  Moon,
  Shield,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Target,
  TimerReset,
  UserRound,
  Waves,
} from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { cn, formatDuration, formatTime } from "@/lib/utils";

type FusionTone = "good" | "warn" | "bad" | "brand" | "neutral";

const TONE_STYLES: Record<FusionTone, string> = {
  good: "border-emerald-400/25 bg-emerald-500/10 text-emerald-200",
  warn: "border-amber-400/25 bg-amber-500/10 text-amber-200",
  bad: "border-rose-400/25 bg-rose-500/10 text-rose-200",
  brand: "border-violet-400/25 bg-violet-500/10 text-violet-200",
  neutral: "border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)]",
};

function clamp(n: number, min = 0, max = 100) {
  return Math.max(min, Math.min(max, n));
}

function deriveState(score: number, detections: ReturnType<typeof useStudyBro>["detections"]) {
  if (detections.presence.status === "AWAY") {
    return { label: "Away", emoji: "⚪", tone: "neutral" as FusionTone, subtitle: "Student is away from the desk." };
  }
  if (detections.phone.status === "DETECTED" || detections.drowsiness.status === "CRITICAL") {
    return { label: "Intervention Required", emoji: "🔴", tone: "bad" as FusionTone, subtitle: "A strong interruption is active now." };
  }
  if (detections.drowsiness.status === "WARNING") {
    return { label: "Fatigued", emoji: "🟠", tone: "warn" as FusionTone, subtitle: "Fatigue signals are rising." };
  }
  if (
    detections.gaze.status === "DISTRACTED" ||
    detections.gaze.status === "SLIGHTLY_DISTRACTED" ||
    detections.posture.status !== "GOOD"
  ) {
    return { label: "Distracted", emoji: "🟡", tone: "warn" as FusionTone, subtitle: "Focus drift or posture issues detected." };
  }
  if (score >= 88) {
    return { label: "Deep Focus", emoji: "🟢", tone: "good" as FusionTone, subtitle: "Signals look stable and aligned." };
  }
  return { label: "Focused", emoji: "🔵", tone: "brand" as FusionTone, subtitle: "Monitoring a stable study session." };
}

function signalTone(ok: boolean, warning = false): FusionTone {
  if (!ok && !warning) return "bad";
  if (warning) return "warn";
  return "good";
}

function progressTone(value: number): FusionTone {
  if (value >= 85) return "good";
  if (value >= 60) return "warn";
  return "bad";
}

function SignalChip({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof Eye;
  label: string;
  value: string;
  tone: FusionTone;
}) {
  return (
    <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/80 p-3 backdrop-blur-sm">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className={cn("grid h-9 w-9 place-items-center rounded-xl border", TONE_STYLES[tone])}>
            <Icon size={17} />
          </span>
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em] text-[var(--text-faint)]">{label}</p>
            <p className="mt-0.5 text-sm font-semibold text-[var(--text)]">{value}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HealthBar({ label, value }: { label: string; value: number }) {
  const tone = progressTone(value);
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between gap-3 text-xs">
        <span className="text-[var(--text-dim)]">{label}</span>
        <span className={cn("font-semibold tabular-nums", tone === "good" ? "text-emerald-300" : tone === "warn" ? "text-amber-300" : "text-rose-300")}>{Math.round(value)}%</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-[var(--surface-2)]">
        <div
          className={cn(
            "h-full rounded-full transition-all duration-500",
            tone === "good"
              ? "bg-gradient-to-r from-emerald-400 to-cyan-400"
              : tone === "warn"
                ? "bg-gradient-to-r from-amber-400 to-orange-400"
                : "bg-gradient-to-r from-rose-400 to-pink-400",
          )}
          style={{ width: `${clamp(value)}%` }}
        />
      </div>
    </div>
  );
}

export function FocusFusionHero() {
  const { detections, focus, explanation, activeAlert, session, events, recoveries } = useStudyBro();
  const state = deriveState(focus.score, detections);

  const attention = clamp(100 - (detections.gaze.status === "DISTRACTED" ? 38 : detections.gaze.status === "SLIGHTLY_DISTRACTED" ? 18 : 4));
  const alertness = clamp(100 - (detections.drowsiness.status === "CRITICAL" ? 65 : detections.drowsiness.status === "WARNING" ? 30 : 6));
  const posture = clamp(session.metrics.postureScore);
  const phoneControl = clamp(100 - Math.min(75, Math.round(detections.phone.usageDurationMs / 1200) * 7));
  const presence = detections.presence.status === "AWAY" ? 35 : detections.presence.faceDetected ? 100 : 70;

  const reasons: string[] = [];
  if (detections.phone.status === "DETECTED") reasons.push(`Phone detected for ${formatDuration(detections.phone.usageDurationMs)}.`);
  if (detections.drowsiness.status === "CRITICAL") reasons.push("Eyes stayed closed long enough to confirm drowsiness.");
  else if (detections.drowsiness.status === "WARNING") reasons.push("Fatigue trend detected from eye openness.");
  if (detections.gaze.status === "DISTRACTED") reasons.push(`Gaze moved ${detections.gaze.direction.toLowerCase()} long enough to confirm distraction.`);
  else if (detections.gaze.status === "SLIGHTLY_DISTRACTED") reasons.push(`Gaze is drifting ${detections.gaze.direction.toLowerCase()}.`);
  if (detections.posture.status !== "GOOD") reasons.push(detections.posture.reason ?? "Posture moved outside the comfortable range.");
  if (detections.presence.status === "AWAY") reasons.push(`Face not visible for ${formatDuration(detections.presence.awayDurationMs)}.`);
  if (reasons.length === 0) reasons.push("Face, eyes, gaze and study posture currently look stable.");

  const lastIntervention = events.find((event) => event.type !== "system");
  const softWarning = detections.drowsiness.status === "WARNING" || detections.gaze.status === "SLIGHTLY_DISTRACTED" || detections.posture.status === "WARNING";
  const confirmedProblem = detections.drowsiness.status === "CRITICAL" || detections.phone.status === "DETECTED" || detections.gaze.status === "DISTRACTED" || detections.posture.status === "BAD" || detections.presence.status === "AWAY";
  const interventionStatus = activeAlert
    ? "LEVEL 3 · VIDEO INTERVENTION"
    : confirmedProblem
      ? "LEVEL 2 · STRONG WARNING"
      : softWarning
        ? "LEVEL 1 · SOFT WARNING"
        : "MONITORING";
  const interventionTone: FusionTone = activeAlert ? "bad" : confirmedProblem || softWarning ? "warn" : "good";
  const averageRecoveryMs = recoveries.length ? recoveries.reduce((sum, item) => sum + item.durationMs, 0) / recoveries.length : 0;

  return (
    <section className="card relative overflow-hidden border-[var(--border-strong)] p-5 sm:p-6">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(139,92,246,0.18),transparent_32%),radial-gradient(circle_at_80%_20%,rgba(34,211,238,0.1),transparent_25%)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-300/40 to-transparent" />

      <div className="relative flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/25 bg-violet-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-violet-200">
            <BrainCircuit size={14} /> Focus Fusion Engine
          </div>
          <h2 className="mt-4 text-2xl font-semibold tracking-tight text-[var(--text)] sm:text-3xl">
            Study state intelligence, not just face detection.
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-[var(--text-dim)]">
            StudyBro fuses live behavior signals into a single explainable study state, then decides when to intervene and how quickly you recover.
          </p>
        </div>
        <div className="grid gap-2 sm:grid-cols-3 xl:min-w-[380px] xl:grid-cols-1">
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/80 px-4 py-3 backdrop-blur-sm">
            <p className="text-[11px] uppercase tracking-[0.14em] text-[var(--text-faint)]">Session focused</p>
            <p className="mt-1 text-lg font-semibold tabular-nums text-[var(--text)]">{formatDuration(session.metrics.focusedTimeMs)}</p>
          </div>
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/80 px-4 py-3 backdrop-blur-sm">
            <p className="text-[11px] uppercase tracking-[0.14em] text-[var(--text-faint)]">Distraction total</p>
            <p className="mt-1 text-lg font-semibold tabular-nums text-[var(--text)]">{formatDuration(session.metrics.distractionTimeMs)}</p>
          </div>
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/80 px-4 py-3 backdrop-blur-sm">
            <p className="text-[11px] uppercase tracking-[0.14em] text-[var(--text-faint)]">Last intervention</p>
            <p className="mt-1 text-sm font-semibold text-[var(--text)]">{lastIntervention ? `${lastIntervention.icon} ${lastIntervention.message}` : "No interventions yet"}</p>
          </div>
        </div>
      </div>

      <div className="relative mt-6 grid gap-4 xl:grid-cols-[1.35fr_0.95fr]">
        <div className="rounded-[1.75rem] border border-violet-400/18 bg-[linear-gradient(180deg,rgba(15,23,42,0.5),rgba(15,23,42,0.22))] p-4 sm:p-5">
          <div className="grid gap-5 lg:grid-cols-[1.1fr_1fr] lg:items-center">
            <div className="rounded-[1.5rem] border border-[var(--border)] bg-[var(--bg)]/55 p-4 text-center shadow-[0_20px_60px_-40px_rgba(56,189,248,0.6)]">
              <div className="mx-auto grid h-44 w-44 place-items-center rounded-full border border-violet-400/20 bg-[radial-gradient(circle_at_50%_30%,rgba(139,92,246,0.22),rgba(15,23,42,0.92)_68%)] shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]">
                <div className="grid h-32 w-32 place-items-center rounded-full border border-white/8 bg-black/25">
                  <div>
                    <p className="text-5xl font-bold tracking-tight text-[var(--text)]">{focus.score}</p>
                    <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-[var(--text-faint)]">Focus State</p>
                  </div>
                </div>
              </div>
              <div className={cn("mx-auto mt-5 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-semibold", TONE_STYLES[state.tone])}>
                <Sparkles size={14} />
                <span>{state.emoji} {state.label}</span>
              </div>
              <p className="mx-auto mt-3 max-w-xs text-sm text-[var(--text-dim)]">{state.subtitle}</p>
            </div>

            <div className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2">
                <SignalChip
                  icon={Eye}
                  label="Eyes"
                  value={detections.drowsiness.eyeState === "closed" ? "Closed" : detections.drowsiness.eyeState === "closing" ? "Closing" : "Open"}
                  tone={signalTone(detections.drowsiness.status === "NORMAL", detections.drowsiness.status === "WARNING")}
                />
                <SignalChip
                  icon={Target}
                  label="Gaze"
                  value={detections.gaze.status === "FOCUSED" ? "Center" : detections.gaze.direction}
                  tone={signalTone(detections.gaze.status === "FOCUSED", detections.gaze.status === "SLIGHTLY_DISTRACTED")}
                />
                <SignalChip
                  icon={Smartphone}
                  label="Phone"
                  value={detections.phone.status === "DETECTED" ? "Detected" : "None"}
                  tone={signalTone(detections.phone.status !== "DETECTED")}
                />
                <SignalChip
                  icon={Waves}
                  label="Posture"
                  value={detections.posture.status}
                  tone={signalTone(detections.posture.status === "GOOD", detections.posture.status === "WARNING")}
                />
                <SignalChip
                  icon={UserRound}
                  label="Presence"
                  value={detections.presence.status === "AWAY" ? "Away" : "Present"}
                  tone={signalTone(detections.presence.status !== "AWAY")}
                />
                <SignalChip
                  icon={Moon}
                  label="Fatigue"
                  value={detections.drowsiness.status === "NORMAL" ? "Low" : detections.drowsiness.status === "WARNING" ? "Rising" : "High"}
                  tone={signalTone(detections.drowsiness.status === "NORMAL", detections.drowsiness.status === "WARNING")}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-4">
          <div className="rounded-[1.5rem] border border-[var(--border)] bg-[var(--surface)]/85 p-4 backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-xl border border-violet-400/25 bg-violet-500/10 text-violet-200">
                <Activity size={17} />
              </span>
              <div>
                <p className="text-sm font-semibold text-[var(--text)]">Why this state?</p>
                <p className="text-xs text-[var(--text-faint)]">Live explanation from current behavior signals</p>
              </div>
            </div>
            <ul className="mt-4 space-y-2">
              {reasons.map((reason, idx) => (
                <li key={`${reason}-${idx}`} className="flex items-start gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg)]/45 px-3 py-2.5 text-sm text-[var(--text)]">
                  <span className="mt-1 h-1.5 w-1.5 rounded-full bg-violet-300" />
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
            {explanation && (
              <div className="mt-3 rounded-xl border border-violet-400/20 bg-violet-500/8 px-3 py-2.5 text-sm text-[var(--text)]">
                <span className="font-semibold text-violet-200">Action:</span> {explanation.action}
              </div>
            )}
          </div>

          <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-1 2xl:grid-cols-2">
            <div className="rounded-[1.5rem] border border-[var(--border)] bg-[var(--surface)]/85 p-4 backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <span className={cn("grid h-9 w-9 place-items-center rounded-xl border", TONE_STYLES[interventionTone])}>
                  {activeAlert ? <AlertTriangle size={17} /> : <ShieldCheck size={17} />}
                </span>
                <div>
                  <p className="text-sm font-semibold text-[var(--text)]">Intervention Engine</p>
                  <p className="text-xs text-[var(--text-faint)]">Detect → Analyze → Decide → Intervene → Measure</p>
                </div>
              </div>
              <div className="mt-4 space-y-2.5 text-sm">
                <div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-[var(--bg)]/45 px-3 py-2">
                  <span className="text-[var(--text-dim)]">Current status</span>
                  <span className={cn("rounded-full border px-2.5 py-1 text-xs font-semibold", TONE_STYLES[interventionTone])}>{interventionStatus}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-[var(--bg)]/45 px-3 py-2">
                  <span className="text-[var(--text-dim)]">Last intervention</span>
                  <span className="max-w-[180px] text-right text-[var(--text)]">{lastIntervention ? `${lastIntervention.icon} ${formatTime(lastIntervention.timestamp)}` : "—"}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-[var(--bg)]/45 px-3 py-2">
                  <span className="text-[var(--text-dim)]">Reason</span>
                  <span className="max-w-[180px] text-right text-[var(--text)]">{activeAlert ? activeAlert.title : "Monitoring"}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-[var(--bg)]/45 px-3 py-2">
                  <span className="text-[var(--text-dim)]">Recovery</span>
                  <span className="text-[var(--text)]">{recoveries.length ? `${Math.max(1, Math.round(averageRecoveryMs / 1000))} sec avg` : "Collecting"}</span>
                </div>
              </div>
            </div>

            <div className="rounded-[1.5rem] border border-[var(--border)] bg-[var(--surface)]/85 p-4 backdrop-blur-sm">
              <div className="mb-4 flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-xl border border-cyan-400/25 bg-cyan-500/10 text-cyan-200">
                  <Shield size={17} />
                </span>
                <div>
                  <p className="text-sm font-semibold text-[var(--text)]">Focus Health</p>
                  <p className="text-xs text-[var(--text-faint)]">Explainable breakdown of your current session</p>
                </div>
              </div>
              <div className="space-y-3">
                <HealthBar label="Attention" value={attention} />
                <HealthBar label="Alertness" value={alertness} />
                <HealthBar label="Posture" value={posture} />
                <HealthBar label="Phone Control" value={phoneControl} />
                <HealthBar label="Presence" value={presence} />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="relative mt-4 grid gap-3 md:grid-cols-3">
        {[
          { label: "Study time", value: formatDuration(session.metrics.studyTimeMs), icon: BrainCircuit },
          { label: "Phone usage", value: formatDuration(session.metrics.phoneUsageMs), icon: Smartphone },
          { label: "Recovery baseline", value: recoveries.length ? `${Math.max(1, Math.round(averageRecoveryMs / 1000))} sec` : "Collecting", icon: TimerReset },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/80 px-4 py-3 backdrop-blur-sm">
              <div className="flex items-center gap-2 text-[var(--text-dim)]">
                <Icon size={15} />
                <span className="text-xs uppercase tracking-[0.12em]">{item.label}</span>
              </div>
              <p className="mt-2 text-lg font-semibold tabular-nums text-[var(--text)]">{item.value}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
