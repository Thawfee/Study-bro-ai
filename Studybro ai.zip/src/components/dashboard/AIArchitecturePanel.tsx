import { ArrowRight, BarChart3, BrainCircuit, Camera, HeartPulse, Radar, ShieldAlert } from "lucide-react";

const STEPS = [
  { label: "Camera", icon: Camera },
  { label: "Vision Analysis", icon: Radar },
  { label: "Behavior Signals", icon: HeartPulse },
  { label: "Focus Fusion", icon: BrainCircuit },
  { label: "Intervention", icon: ShieldAlert },
  { label: "Recovery", icon: BarChart3 },
];

export function AIArchitecturePanel() {
  return (
    <div className="card p-5">
      <div><h3 className="text-sm font-semibold text-[var(--text)]">StudyBro Intelligence Loop</h3><p className="text-xs text-[var(--text-faint)]">The architecture judges should understand at a glance</p></div>
      <div className="mt-4 grid gap-2 sm:grid-cols-3 xl:grid-cols-6">
        {STEPS.map((step, index) => {
          const Icon = step.icon;
          return <div key={step.label} className="relative rounded-2xl border border-[var(--border)] bg-[var(--surface)]/75 p-3 text-center"><span className="mx-auto grid h-9 w-9 place-items-center rounded-xl border border-violet-400/20 bg-violet-500/10 text-violet-200"><Icon size={16}/></span><p className="mt-2 text-xs font-semibold text-[var(--text)]">{step.label}</p>{index < STEPS.length - 1 && <ArrowRight className="absolute -right-3 top-1/2 z-10 hidden -translate-y-1/2 text-violet-300 xl:block" size={14}/>}</div>;
        })}
      </div>
    </div>
  );
}
