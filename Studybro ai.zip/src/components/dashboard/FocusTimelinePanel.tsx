"use client";

import { History } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { cn, formatTime, timeAgo } from "@/lib/utils";

function toneClass(type: string, severity: string) {
  if (type === "system") return "border-violet-400/20 bg-violet-500/10 text-violet-200";
  if (severity === "critical") return "border-rose-400/20 bg-rose-500/10 text-rose-200";
  if (severity === "warning") return "border-amber-400/20 bg-amber-500/10 text-amber-200";
  return "border-emerald-400/20 bg-emerald-500/10 text-emerald-200";
}

export function FocusTimelinePanel({ limit = 8 }: { limit?: number }) {
  const { events, now } = useStudyBro();
  const list = events.slice(0, limit);

  return (
    <div className="card flex h-full flex-col p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg border border-cyan-400/25 bg-cyan-500/10 text-cyan-200">
            <History size={16} />
          </span>
          <div>
            <h3 className="text-sm font-semibold text-[var(--text)]">Focus Timeline</h3>
            <p className="text-xs text-[var(--text-faint)]">Beautiful live history of what happened this session</p>
          </div>
        </div>
        <span className="text-[11px] text-[var(--text-faint)]">{events.length} events</span>
      </div>

      {list.length === 0 ? (
        <div className="grid flex-1 place-items-center rounded-2xl border border-dashed border-[var(--border)] bg-[var(--surface)]/55 text-center">
          <div className="p-6">
            <p className="text-sm text-[var(--text-dim)]">Timeline will populate as StudyBro monitors your session.</p>
          </div>
        </div>
      ) : (
        <ul className="space-y-3">
          {list.map((event, idx) => (
            <li key={event.id} className="relative rounded-2xl border border-[var(--border)] bg-[var(--surface)]/70 p-3.5">
              {idx < list.length - 1 && <span className="absolute bottom-[-14px] left-[22px] top-[46px] w-px bg-gradient-to-b from-violet-400/35 to-transparent" />}
              <div className="flex items-start gap-3">
                <span className={cn("relative z-10 grid h-8 w-8 shrink-0 place-items-center rounded-xl border text-sm", toneClass(event.type, event.severity))}>
                  {event.icon}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-medium text-[var(--text)]">{event.message}</p>
                    <span className="text-[11px] tabular-nums text-[var(--text-faint)]">{formatTime(event.timestamp)}</span>
                  </div>
                  <p className="mt-1 text-xs text-[var(--text-dim)]">{timeAgo(event.timestamp, now || undefined)}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
