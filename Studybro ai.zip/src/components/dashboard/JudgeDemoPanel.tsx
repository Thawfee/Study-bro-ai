"use client";

import { useEffect, useState } from "react";
import { Play, Square, Sparkles } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import type { DetectionType } from "@/types/ai";

const STEPS: Array<{ title: string; detail: string; type?: DetectionType; system?: [string,string] }> = [
  { title: "Face detected", detail: "Introduce the live vision monitor.", system: ["🙂", "Demo: face detected"] },
  { title: "Eyes tracked", detail: "Show eye contours and live openness.", system: ["👁️", "Demo: eye tracking active"] },
  { title: "Look away", detail: "Demonstrate sustained distraction.", type: "distraction" },
  { title: "Phone detected", detail: "Show object detection and intervention.", type: "phone" },
  { title: "Drowsiness detected", detail: "Show the wake-up intervention.", type: "drowsiness" },
  { title: "Intervention", detail: "Explain why StudyBro chose a stronger response.", system: ["🎥", "Demo: intervention engine engaged"] },
  { title: "Recovery", detail: "Explain automatic recovery measurement in live mode.", system: ["✅", "Demo: recovery measurement highlighted"] },
];

export function JudgeDemoPanel({ compact = false }: { compact?: boolean }) {
  const { trigger, pushSystemEvent, closeAlert, reset, mode } = useStudyBro();
  const [running, setRunning] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!running) return;
    const current = STEPS[step];
    closeAlert();
    if (current.type) trigger(current.type);
    if (current.system) pushSystemEvent(current.system[0], current.system[1]);
    const id = window.setTimeout(() => {
      if (step >= STEPS.length - 1) { closeAlert(); setRunning(false); }
      else setStep((s) => s + 1);
    }, 2600);
    return () => window.clearTimeout(id);
  }, [running, step, trigger, pushSystemEvent, closeAlert]);

  const start = () => { if (mode === "live") return; reset(); closeAlert(); setStep(0); setRunning(true); };
  const stop = () => { setRunning(false); closeAlert(); };

  return <div className={compact ? "rounded-2xl border border-amber-400/20 bg-amber-500/8 p-4" : "card p-5"}>
    <div className="flex flex-wrap items-center justify-between gap-3"><div><div className="inline-flex items-center gap-2 text-amber-200"><Sparkles size={14}/><span className="text-[11px] font-semibold uppercase tracking-[0.16em]">Demo Mode</span></div><h3 className="mt-1 text-sm font-semibold text-[var(--text)]">Judge Demo Flow</h3><p className="text-xs text-[var(--text-faint)]">{mode === "live" ? "Live AI is active — stop the camera before running this controlled simulation." : "Controlled simulation only — never used as fake live AI."}</p></div>{running ? <button onClick={stop} className="inline-flex items-center gap-2 rounded-xl border border-rose-400/25 bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-200"><Square size={13}/> Stop demo</button> : <button onClick={start} disabled={mode === "live"} title={mode === "live" ? "Stop live camera monitoring before running the controlled demo." : undefined} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-2 text-xs font-semibold text-white disabled:cursor-not-allowed disabled:opacity-40"><Play size={13}/> Run Demo</button>}</div>
    <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">{STEPS.map((s,i)=><div key={s.title} className={`rounded-xl border px-3 py-2.5 ${i===step && running ? "border-amber-400/40 bg-amber-500/15" : i<step || (!running && step===STEPS.length-1) ? "border-emerald-400/20 bg-emerald-500/8" : "border-[var(--border)] bg-[var(--surface)]/65"}`}><p className="text-[10px] uppercase tracking-wider text-[var(--text-faint)]">Step {i+1}</p><p className="mt-0.5 text-xs font-semibold text-[var(--text)]">{s.title}</p>{!compact && <p className="mt-1 text-[11px] text-[var(--text-dim)]">{s.detail}</p>}</div>)}</div>
  </div>;
}
