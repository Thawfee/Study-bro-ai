"use client";

import { useStudyBro } from "@/lib/store/studybro-store";
import { useWorkspace } from "@/lib/store/workspace-store";
import { ProgressBar } from "@/components/ui/common";
import { formatDuration } from "@/lib/utils";

export function DailyProgress() {
  const { focus, session } = useStudyBro();
  const { tasks, goals } = useWorkspace();

  const tasksDone = tasks.filter((t) => t.done).length;
  const goalsDone = goals.filter((g) => g.current >= g.target).length;
  const studyGoalMs = 4 * 3600e3; // 4h daily target
  const studied = session.metrics.studyTimeMs;

  const rows = [
    { label: "Study goal", value: `${formatDuration(studied)} / 4h`, pct: studied / studyGoalMs, tone: "brand" as const },
    { label: "Focus score", value: `${focus.score}%`, pct: focus.score / 100, tone: "good" as const },
    { label: "Tasks", value: `${tasksDone} / ${tasks.length}`, pct: tasks.length ? tasksDone / tasks.length : 0, tone: "brand" as const },
    { label: "Goals", value: `${goalsDone} / ${goals.length}`, pct: goals.length ? goalsDone / goals.length : 0, tone: "good" as const },
  ];

  return (
    <div className="card p-5">
      <h3 className="mb-4 text-sm font-semibold text-[var(--text)]">Today&apos;s Progress</h3>
      <div className="space-y-4">
        {rows.map((r) => (
          <div key={r.label}>
            <div className="mb-1.5 flex items-center justify-between text-sm">
              <span className="text-[var(--text-dim)]">{r.label}</span>
              <span className="font-medium tabular-nums text-[var(--text)]">{r.value}</span>
            </div>
            <ProgressBar value={r.pct} tone={r.tone} />
          </div>
        ))}
      </div>
    </div>
  );
}
