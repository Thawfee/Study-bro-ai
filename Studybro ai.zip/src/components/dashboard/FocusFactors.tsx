"use client";

import { Minus, Plus } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { cn, formatTime } from "@/lib/utils";

export function FocusFactors() {
  const { focus } = useStudyBro();
  const factors = focus.factors.slice(0, 6);

  return (
    <div>
      <h3 className="mb-3 text-sm font-semibold text-[var(--text)]">Focus Score Factors</h3>
      {factors.length === 0 ? (
        <p className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-4 text-center text-xs text-[var(--text-faint)]">
          No adjustments yet — you&apos;re at a perfect 100. Keep it up! 🎯
        </p>
      ) : (
        <ul className="space-y-1.5">
          {factors.map((f) => {
            const positive = f.delta >= 0;
            return (
              <li
                key={f.id}
                className="flex items-center justify-between rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2"
              >
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "grid h-6 w-6 place-items-center rounded-md",
                      positive ? "bg-emerald-500/15 text-emerald-300" : "bg-rose-500/15 text-rose-300",
                    )}
                  >
                    {positive ? <Plus size={13} /> : <Minus size={13} />}
                  </span>
                  <span className="text-sm text-[var(--text)]">{f.label}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] text-[var(--text-faint)]">{formatTime(f.timestamp)}</span>
                  <span
                    className={cn(
                      "w-10 text-right text-sm font-semibold tabular-nums",
                      positive ? "text-emerald-300" : "text-rose-300",
                    )}
                  >
                    {positive ? "+" : ""}
                    {f.delta}
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
