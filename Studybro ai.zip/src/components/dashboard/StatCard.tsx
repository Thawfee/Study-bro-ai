import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

const TONES = {
  brand: "border-violet-400/30 bg-violet-500/10 text-violet-300",
  cyan: "border-cyan-400/30 bg-cyan-500/10 text-cyan-300",
  good: "border-emerald-400/30 bg-emerald-500/10 text-emerald-300",
  amber: "border-amber-400/30 bg-amber-500/10 text-amber-300",
};

export function StatCard({
  icon: Icon,
  label,
  value,
  hint,
  tone = "brand",
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  hint?: string;
  tone?: keyof typeof TONES;
}) {
  return (
    <div className="card p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-[var(--text-dim)]">{label}</span>
        <span className={cn("grid h-8 w-8 place-items-center rounded-lg border", TONES[tone])}>
          <Icon size={16} />
        </span>
      </div>
      <p className="mt-3 text-2xl font-bold tabular-nums text-[var(--text)] sm:text-3xl">{value}</p>
      {hint && <p className="mt-1 text-xs text-[var(--text-faint)]">{hint}</p>}
    </div>
  );
}
