"use client";

import { useState } from "react";
import { Play, Pause, RotateCcw, Zap } from "lucide-react";
import { useStudyTimer } from "@/hooks/useStudyTimer";
import { formatClock, cn } from "@/lib/utils";

const MODES = [
  { label: "Pomodoro", minutes: 25 },
  { label: "Deep Work", minutes: 50 },
  { label: "Custom", minutes: 15 },
];

export function QuickFocus() {
  const timer = useStudyTimer(25);
  const [mode, setMode] = useState("Pomodoro");

  const pick = (label: string, minutes: number) => {
    setMode(label);
    timer.setMinutes(minutes);
  };

  return (
    <div className="card p-5">
      <div className="mb-4 flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg border border-violet-400/30 bg-violet-500/10 text-violet-300">
          <Zap size={16} />
        </span>
        <h3 className="text-sm font-semibold text-[var(--text)]">Quick Focus</h3>
      </div>

      <div className="mb-4 flex gap-2">
        {MODES.map((m) => (
          <button
            key={m.label}
            onClick={() => pick(m.label, m.minutes)}
            className={cn(
              "flex-1 rounded-lg border px-2 py-1.5 text-xs font-medium transition-colors",
              mode === m.label
                ? "border-violet-400/40 bg-violet-500/15 text-violet-200"
                : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:text-[var(--text)]",
            )}
          >
            {m.label}
          </button>
        ))}
      </div>

      <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] py-6 text-center">
        <p className="text-5xl font-bold tabular-nums text-[var(--text)]">{formatClock(timer.secondsLeft)}</p>
        <p className="mt-1 text-xs uppercase tracking-widest text-[var(--text-faint)]">
          {timer.isFinished ? "Session done 🎉" : timer.isRunning ? "Locked in 🔥" : mode}
        </p>
      </div>

      <div className="mt-4 flex gap-2">
        {timer.isRunning ? (
          <button onClick={timer.pause} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm font-medium text-[var(--text)] hover:bg-[var(--surface-2)]">
            <Pause size={15} /> Pause
          </button>
        ) : (
          <button onClick={timer.start} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-gradient-to-r from-violet-500 to-indigo-500 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-violet-500/25 hover:brightness-110">
            <Play size={15} /> Start
          </button>
        )}
        <button onClick={timer.reset} aria-label="Reset" className="grid h-[42px] w-[42px] place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:bg-[var(--surface-2)]">
          <RotateCcw size={16} />
        </button>
      </div>
    </div>
  );
}
