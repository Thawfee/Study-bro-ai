"use client";

import { RotateCcw } from "lucide-react";
import { useDemoAI } from "@/hooks/useDemoAI";
import { DemoModeBadge } from "@/components/brand/DemoModeBadge";
import type { DetectionType } from "@/types/ai";

const TRIGGERS: { type: DetectionType; emoji: string; label: string }[] = [
  { type: "drowsiness", emoji: "😴", label: "Trigger Sleep" },
  { type: "phone", emoji: "📱", label: "Trigger Phone" },
  { type: "distraction", emoji: "👀", label: "Trigger Distraction" },
  { type: "posture", emoji: "🪑", label: "Trigger Bad Posture" },
  { type: "away", emoji: "🚶", label: "Trigger Student Away" },
];

export function DemoControlPanel() {
  const { triggerByType, reset } = useDemoAI();

  return (
    <div className="card p-5">
      <div className="mb-1 flex items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-[var(--text)]">Demo Control Panel</h3>
        <DemoModeBadge />
      </div>
      <p className="mb-4 text-xs text-[var(--text-dim)]">
        Simulate a detection to see the full pipeline: score → event → alert → video.
      </p>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {TRIGGERS.map((t) => (
          <button
            key={t.type}
            onClick={() => triggerByType(t.type)}
            className="group flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3 py-2.5 text-left text-sm font-medium text-[var(--text)] transition-all hover:border-white/20 hover:bg-white/[0.05] active:scale-[0.98]"
          >
            <span className="text-lg transition-transform group-hover:scale-110">{t.emoji}</span>
            {t.label}
          </button>
        ))}
        <button
          onClick={reset}
          className="flex items-center justify-center gap-2 rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-3 py-2.5 text-sm font-semibold text-emerald-300 transition-all hover:bg-emerald-500/15 active:scale-[0.98]"
        >
          <RotateCcw size={15} /> Reset
        </button>
      </div>
    </div>
  );
}
