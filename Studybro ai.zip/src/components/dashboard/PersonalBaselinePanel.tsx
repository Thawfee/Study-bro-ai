"use client";

import { useEffect, useMemo } from "react";
import { useStoredState } from "@/hooks/useStoredState";
import { Activity, History, UserRound } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatDuration } from "@/lib/utils";

type BaselineSample = {
  sessionId: number;
  studyTimeMs: number;
  focusedTimeMs: number;
  phoneUsageMs: number;
  distractionTimeMs: number;
  postureScore: number;
};

const KEY = "studybro.focus-baseline.v1";

const NO_SAMPLES: BaselineSample[] = [];

export function PersonalBaselinePanel() {
  const { session } = useStudyBro();
  const [samples, setSamples] = useStoredState<BaselineSample[]>(KEY, NO_SAMPLES);
  const minuteBucket = Math.floor(session.metrics.studyTimeMs / 60_000);

  // Save a coarse snapshot of the current session once per tracked minute.
  // setSamples merges into what is ALREADY stored, so opening this panel can
  // never wipe earlier sessions. A session only exists once monitoring has
  // actually started (see studybro-store), so idle app time is not recorded.
  useEffect(() => {
    // Only real camera sessions build the baseline — never demo simulations.
    if (!session.startedAt || session.source !== "live" || minuteBucket < 1) return;
    const sample: BaselineSample = {
      sessionId: session.startedAt,
      studyTimeMs: session.metrics.studyTimeMs,
      focusedTimeMs: session.metrics.focusedTimeMs,
      phoneUsageMs: session.metrics.phoneUsageMs,
      distractionTimeMs: session.metrics.distractionTimeMs,
      postureScore: session.metrics.postureScore,
    };
    setSamples((prev) => [sample, ...prev.filter((x) => x.sessionId !== sample.sessionId)].slice(0, 12));
    // Snapshot only when the minute bucket changes, not on every tick.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session.startedAt, session.source, minuteBucket]);

  const baseline = useMemo(() => {
    const prior = samples.filter((x) => x.sessionId !== session.startedAt);
    if (!prior.length) return null;
    const avg = (pick: (x: BaselineSample) => number) => prior.reduce((a, x) => a + pick(x), 0) / prior.length;
    return {
      sessions: prior.length,
      studyTimeMs: avg((x) => x.studyTimeMs),
      focusRatio: avg((x) => x.studyTimeMs ? x.focusedTimeMs / x.studyTimeMs : 0),
      phoneUsageMs: avg((x) => x.phoneUsageMs),
      distractionTimeMs: avg((x) => x.distractionTimeMs),
      postureScore: avg((x) => x.postureScore),
    };
  }, [samples, session.startedAt]);

  const currentRatio = session.metrics.studyTimeMs ? session.metrics.focusedTimeMs / session.metrics.studyTimeMs : 0;

  return (
    <div className="card p-5">
      <div className="flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-xl border border-cyan-400/25 bg-cyan-500/10 text-cyan-200"><UserRound size={17} /></span>
        <div>
          <h3 className="text-sm font-semibold text-[var(--text)]">Personal Focus Baseline</h3>
          <p className="text-xs text-[var(--text-faint)]">Built only from your saved StudyBro session data</p>
        </div>
      </div>

      {!baseline ? (
        <div className="mt-4 rounded-2xl border border-dashed border-[var(--border)] bg-[var(--surface)]/60 p-5 text-center">
          <History className="mx-auto h-6 w-6 text-[var(--text-faint)]" />
          <p className="mt-2 text-sm text-[var(--text-dim)]">Baseline is calibrating.</p>
          <p className="mt-1 text-xs text-[var(--text-faint)]">Complete at least one minute-long session; later sessions will be compared against your own prior pattern.</p>
        </div>
      ) : (
        <div className="mt-4 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <Metric label="Typical session" value={formatDuration(baseline.studyTimeMs)} />
            <Metric label="Typical focus ratio" value={`${Math.round(baseline.focusRatio * 100)}%`} />
            <Metric label="Typical phone time" value={formatDuration(baseline.phoneUsageMs)} />
            <Metric label="Typical posture" value={`${Math.round(baseline.postureScore)}%`} />
          </div>
          <div className="rounded-2xl border border-violet-400/20 bg-violet-500/8 p-3.5">
            <div className="flex items-center gap-2 text-violet-200"><Activity size={14} /><span className="text-xs font-semibold uppercase tracking-[0.14em]">Current vs usual</span></div>
            <p className="mt-2 text-sm text-[var(--text)]">
              Current focus ratio is <strong>{Math.round(currentRatio * 100)}%</strong> versus your usual <strong>{Math.round(baseline.focusRatio * 100)}%</strong> across {baseline.sessions} prior session{baseline.sessions === 1 ? "" : "s"}.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/75 p-3"><p className="text-[10px] uppercase tracking-[0.12em] text-[var(--text-faint)]">{label}</p><p className="mt-1 text-base font-semibold tabular-nums text-[var(--text)]">{value}</p></div>;
}
