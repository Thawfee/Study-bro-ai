"use client";

import { BarChart3, Sparkles } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatDuration } from "@/lib/utils";

export function SessionSummaryPanel() {
  const { focus, session, recoveries } = useStudyBro();
  const m = session.metrics;
  const avgRecovery = recoveries.length ? recoveries.reduce((a, r) => a + r.durationMs, 0) / recoveries.length : 0;
  const focusRatio = m.studyTimeMs ? m.focusedTimeMs / m.studyTimeMs : 0;

  const summary = m.studyTimeMs < 15_000
    ? "Keep studying to build a meaningful session summary."
    : focusRatio >= 0.8
      ? "You maintained strong focus for most of this session. Keep the environment and routine that helped you stay on task."
      : m.phoneUsageMs > m.distractionTimeMs
        ? "Phone usage was your largest recorded interruption. Moving the phone outside immediate reach may improve the next session."
        : "Your session had some focus drift. Use the timeline to identify when attention changed and adjust your study setup next time.";

  return (
    <div className="card p-5">
      <div className="flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-xl border border-violet-400/25 bg-violet-500/10 text-violet-200"><BarChart3 size={17} /></span>
        <div><h3 className="text-sm font-semibold text-[var(--text)]">AI Session Summary</h3><p className="text-xs text-[var(--text-faint)]">Generated deterministically from real session metrics</p></div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Metric label="Study time" value={formatDuration(m.studyTimeMs)} />
        <Metric label="Focused" value={formatDuration(m.focusedTimeMs)} />
        <Metric label="Phone" value={formatDuration(m.phoneUsageMs)} />
        <Metric label="Focus score" value={`${focus.score}/100`} />
        <Metric label="Distraction" value={formatDuration(m.distractionTimeMs)} />
        <Metric label="Drowsiness" value={formatDuration(m.drowsinessMs)} />
        <Metric label="Posture" value={`${Math.round(m.postureScore)}%`} />
        <Metric label="Avg. recovery" value={recoveries.length ? formatDuration(avgRecovery) : "Collecting"} />
      </div>
      <div className="mt-3 rounded-2xl border border-violet-400/20 bg-violet-500/8 p-4">
        <div className="flex items-center gap-2 text-violet-200"><Sparkles size={14} /><span className="text-xs font-semibold uppercase tracking-[0.14em]">Session insight</span></div>
        <p className="mt-2 text-sm leading-relaxed text-[var(--text)]">{summary}</p>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/75 p-3"><p className="text-[10px] uppercase tracking-[0.12em] text-[var(--text-faint)]">{label}</p><p className="mt-1 text-sm font-semibold tabular-nums text-[var(--text)]">{value}</p></div>;
}
