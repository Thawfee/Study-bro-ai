"use client";

import { useStudyBro } from "@/lib/store/studybro-store";
import { scoreTone } from "@/lib/ai/focus-engine";
import { TONE } from "@/lib/tone";
import { cn } from "@/lib/utils";

const TONE_HEX = {
  good: "#34d399",
  warn: "#fbbf24",
  bad: "#fb7185",
} as const;

export function FocusScoreRing({ size = 190 }: { size?: number }) {
  const { focus } = useStudyBro();
  const tone = scoreTone(focus.score);
  const stroke = 12;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (focus.score / 100) * c;
  const color = TONE_HEX[tone];

  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,0.07)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{
            transition: "stroke-dashoffset 0.7s cubic-bezier(0.22,1,0.36,1), stroke 0.4s",
            filter: `drop-shadow(0 0 6px ${color}66)`,
          }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-5xl font-bold tabular-nums text-[var(--text)]">{focus.score}</span>
        <span className="text-xs font-medium uppercase tracking-widest text-[var(--text-faint)]">
          Focus Score
        </span>
        <span className={cn("mt-1.5 text-sm font-semibold", TONE[tone].text)}>
          {focus.status}
        </span>
      </div>
    </div>
  );
}
