"use client";

import { Radio } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { severityTone, TONE } from "@/lib/tone";
import { cn, formatTime, timeAgo } from "@/lib/utils";

export function EventFeed({ limit = 12 }: { limit?: number }) {
  const { events, now } = useStudyBro();
  const list = events.slice(0, limit);

  return (
    <div className="card flex h-full flex-col p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg border border-cyan-400/30 bg-cyan-500/10 text-cyan-300">
            <Radio size={16} />
          </span>
          <div>
            <h3 className="text-sm font-semibold text-[var(--text)]">Intervention Log</h3>
            <p className="text-xs text-[var(--text-faint)]">Raw event stream from the AI engine</p>
          </div>
        </div>
        <span className="text-[11px] text-[var(--text-faint)]">{events.length} total</span>
      </div>

      {list.length === 0 ? (
        <div className="grid flex-1 place-items-center rounded-2xl border border-dashed border-[var(--border)] bg-[var(--surface)]/60 py-8 text-center text-xs text-[var(--text-faint)]">
          Waiting for events…
        </div>
      ) : (
        <ul className="space-y-2 overflow-y-auto pr-1">
          {list.map((e) => {
            const tone = e.type === "system" ? "brand" : severityTone(e.severity);
            return (
              <li key={e.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/70 p-3">
                <div className="flex items-start gap-3">
                  <span
                    className={cn(
                      "mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl border text-sm",
                      TONE[tone].bg,
                      TONE[tone].border,
                    )}
                  >
                    {e.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <p className="text-sm text-[var(--text)]">{e.message}</p>
                      <span className="text-[11px] text-[var(--text-faint)]">{formatTime(e.timestamp)}</span>
                    </div>
                    <p className="mt-1 text-[11px] text-[var(--text-faint)]">{timeAgo(e.timestamp, now || undefined)}</p>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
