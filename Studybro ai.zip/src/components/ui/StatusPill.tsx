import { cn } from "@/lib/utils";
import { TONE, type Tone } from "@/lib/tone";

export function StatusPill({
  label,
  tone = "neutral",
  pulse = false,
  className,
}: {
  label: string;
  tone?: Tone;
  pulse?: boolean;
  className?: string;
}) {
  const t = TONE[tone];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold tracking-wide",
        t.bg,
        t.border,
        t.text,
        className,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", t.dot, pulse && "pulse-dot")} />
      {label}
    </span>
  );
}
