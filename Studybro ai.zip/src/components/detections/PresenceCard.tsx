"use client";

import { UserRound } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatDuration, formatTime } from "@/lib/utils";
import { DetectionCard, MetricRow } from "./DetectionCard";

export function PresenceCard() {
  const { detections } = useStudyBro();
  const p = detections.presence;
  const away = p.status === "AWAY";
  const tone = away ? "bad" : "good";

  return (
    <DetectionCard
      icon={UserRound}
      emoji="🚶"
      title="Presence"
      statusLabel={away ? "AWAY" : "PRESENT"}
      tone={tone}
      active={away}
      lastDetected={p.lastDetected}
    >
      <MetricRow label="Face detected" value={p.faceDetected ? "Yes" : "No"} tone={p.faceDetected ? "good" : "bad"} />
      <MetricRow label="Away duration" value={formatDuration(p.awayDurationMs)} tone={away ? "bad" : undefined} />
      <MetricRow label="Last seen" value={p.lastDetected ? formatTime(p.lastDetected) : "Now"} />
    </DetectionCard>
  );
}
