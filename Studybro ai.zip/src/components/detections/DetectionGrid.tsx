import { DrowsinessCard } from "./DrowsinessCard";
import { PhoneCard } from "./PhoneCard";
import { GazeCard } from "./GazeCard";
import { PostureCard } from "./PostureCard";
import { PresenceCard } from "./PresenceCard";

/** The five reusable detection cards, laid out responsively. */
export function DetectionGrid() {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
      <DrowsinessCard />
      <PhoneCard />
      <GazeCard />
      <PostureCard />
      <PresenceCard />
    </div>
  );
}
