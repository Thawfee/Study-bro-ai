import type { LucideIcon } from "lucide-react";
import { cn, formatTime } from "@/lib/utils";
import { TONE, type Tone } from "@/lib/tone";
import { StatusPill } from "@/components/ui/StatusPill";

/** Consistent shell for every detection card. */
export function DetectionCard({
  icon: Icon,
  emoji,
  title,
  statusLabel,
  tone,
  active,
  lastDetected,
  children,
}: {
  icon: LucideIcon;
  emoji: string;
  title: string;
  statusLabel: string;
  tone: Tone;
  active: boolean;
  lastDetected: number | null;
  children: React.ReactNode;
}) {
  const t = TONE[tone];
  return (
    <div
      className={cn(
        "card relative overflow-hidden p-4 transition-all duration-300",
        active ? cn(t.border, "shadow-[0_20px_50px_-36px_rgba(0,0,0,0.85)]") : "hover:border-white/15",
      )}
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/18 to-transparent" />
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className={cn("grid h-10 w-10 place-items-center rounded-2xl border", t.bg, t.border)} aria-hidden>
            <Icon className={t.text} size={18} />
          </span>
          <div>
            <p className="text-sm font-semibold text-[var(--text)]">
              <span className="mr-1">{emoji}</span>
              {title}
            </p>
            <p className="text-[11px] text-[var(--text-faint)]">{lastDetected ? `Last: ${formatTime(lastDetected)}` : "No recent events"}</p>
          </div>
        </div>
        <StatusPill label={statusLabel} tone={tone} pulse={active} />
      </div>

      <div className="mt-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)]/70 p-3.5">
        <div className="space-y-2.5">{children}</div>
      </div>
    </div>
  );
}

/** A labeled metric row inside a detection card. */
export function MetricRow({
  label,
  value,
  tone,
}: {
  label: string;
  value: React.ReactNode;
  tone?: Tone;
}) {
  return (
    <div className="flex items-center justify-between gap-3 text-sm">
      <span className="text-[var(--text-dim)]">{label}</span>
      <span className={cn("text-right font-medium", tone ? TONE[tone].text : "text-[var(--text)]")}>{value}</span>
    </div>
  );
}

/** A thin confidence / progress bar. */
export function MiniBar({ value, tone = "brand" }: { value: number; tone?: Tone }) {
  const pct = Math.max(0, Math.min(100, Math.round(value * 100)));
  return (
    <div className="flex items-center gap-2">
      <div className="h-2 flex-1 overflow-hidden rounded-full bg-[var(--surface-2)]">
        <div className={cn("h-full rounded-full transition-all duration-500", TONE[tone].dot)} style={{ width: `${pct}%` }} />
      </div>
      <span className="w-9 text-right text-xs tabular-nums text-[var(--text-dim)]">{pct}%</span>
    </div>
  );
}
