"use client";

import { Eye } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { gazeStatusLabel } from "@/lib/ai/gaze";
import { cn, formatDuration } from "@/lib/utils";
import type { Tone } from "@/lib/tone";
import type { GazeDirection } from "@/types/ai";
import { DetectionCard, MetricRow, MiniBar } from "./DetectionCard";

const TONE_BY_STATUS: Record<string, Tone> = {
  FOCUSED: "good",
  SLIGHTLY_DISTRACTED: "warn",
  DISTRACTED: "bad",
};

const DIRECTIONS: GazeDirection[] = ["UP", "LEFT", "CENTER", "RIGHT", "DOWN"];

export function GazeCard() {
  const { detections } = useStudyBro();
  const g = detections.gaze;
  const tone = TONE_BY_STATUS[g.status];
  const active = g.status !== "FOCUSED";

  return (
    <DetectionCard
      icon={Eye}
      emoji="👀"
      title="Gaze / Distraction"
      statusLabel={gazeStatusLabel(g.status)}
      tone={tone}
      active={active}
      lastDetected={g.lastDetected}
    >
      {/* direction indicator */}
      <div className="grid grid-cols-5 gap-1">
        {DIRECTIONS.map((dir) => {
          const on = g.direction === dir;
          return (
            <span
              key={dir}
              className={cn(
                "rounded-md border px-1 py-1 text-center text-[10px] font-semibold tracking-wide transition-colors",
                on
                  ? active
                    ? "border-rose-400/40 bg-rose-500/15 text-rose-200"
                    : "border-emerald-400/40 bg-emerald-500/15 text-emerald-200"
                  : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-faint)]",
              )}
            >
              {dir}
            </span>
          );
        })}
      </div>
      <MetricRow label="Distraction duration" value={formatDuration(g.distractionDurationMs)} tone={active ? "bad" : undefined} />
      <div>
        <p className="mb-1 text-xs text-[var(--text-dim)]">Confidence</p>
        <MiniBar value={g.confidence} tone={tone} />
      </div>
    </DetectionCard>
  );
}
