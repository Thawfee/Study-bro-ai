"use client";

import { Moon } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { eyeStateLabel } from "@/lib/ai/drowsiness";
import { formatTime } from "@/lib/utils";
import type { Tone } from "@/lib/tone";
import { DetectionCard, MetricRow, MiniBar } from "./DetectionCard";

const TONE_BY_STATUS: Record<string, Tone> = {
  NORMAL: "good",
  WARNING: "warn",
  CRITICAL: "bad",
};

export function DrowsinessCard() {
  const { detections } = useStudyBro();
  const d = detections.drowsiness;
  const tone = TONE_BY_STATUS[d.status];
  const active = d.status !== "NORMAL";

  return (
    <DetectionCard
      icon={Moon}
      emoji="😴"
      title="Drowsiness"
      statusLabel={d.status}
      tone={tone}
      active={active}
      lastDetected={d.lastDetected}
    >
      <MetricRow label="Eye state" value={eyeStateLabel(d.eyeState)} tone={active ? "bad" : "good"} />
      <div>
        <p className="mb-1 text-xs text-[var(--text-dim)]">Drowsiness confidence</p>
        <MiniBar value={d.confidence} tone={tone} />
      </div>
      <MetricRow
        label="Last detected"
        value={d.lastDetected ? formatTime(d.lastDetected) : "—"}
      />
    </DetectionCard>
  );
}
