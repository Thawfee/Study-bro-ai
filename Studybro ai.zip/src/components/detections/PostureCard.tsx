"use client";

import { Armchair } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatTime } from "@/lib/utils";
import type { Tone } from "@/lib/tone";
import { DetectionCard, MetricRow, MiniBar } from "./DetectionCard";

const TONE_BY_STATUS: Record<string, Tone> = {
  GOOD: "good",
  WARNING: "warn",
  BAD: "bad",
};

export function PostureCard() {
  const { detections } = useStudyBro();
  const p = detections.posture;
  const tone = TONE_BY_STATUS[p.status];
  const active = p.status !== "GOOD";

  return (
    <DetectionCard
      icon={Armchair}
      emoji="🪑"
      title="Posture"
      statusLabel={p.status}
      tone={tone}
      active={active}
      lastDetected={p.lastDetected}
    >
      <MetricRow label="Assessment" value={p.reason ?? "Upright & centered"} tone={active ? "warn" : "good"} />
      <div>
        <p className="mb-1 text-xs text-[var(--text-dim)]">Confidence</p>
        <MiniBar value={p.confidence} tone={tone} />
      </div>
      <MetricRow label="Last detected" value={p.lastDetected ? formatTime(p.lastDetected) : "—"} />
    </DetectionCard>
  );
}
