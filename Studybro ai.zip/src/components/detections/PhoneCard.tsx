"use client";

import { Smartphone } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatDuration, formatTime } from "@/lib/utils";
import { DetectionCard, MetricRow, MiniBar } from "./DetectionCard";

export function PhoneCard() {
  const { detections } = useStudyBro();
  const p = detections.phone;
  const detected = p.status === "DETECTED";
  const tone = detected ? "bad" : "good";

  return (
    <DetectionCard
      icon={Smartphone}
      emoji="📱"
      title="Phone"
      statusLabel={detected ? "DETECTED" : "NOT DETECTED"}
      tone={tone}
      active={detected}
      lastDetected={p.lastDetected}
    >
      <div>
        <p className="mb-1 text-xs text-[var(--text-dim)]">Confidence</p>
        <MiniBar value={p.confidence} tone={tone} />
      </div>
      <MetricRow
        label="Phone usage"
        value={formatDuration(p.usageDurationMs)}
        tone={detected ? "bad" : undefined}
      />
      <MetricRow
        label="Last detected"
        value={p.lastDetected ? formatTime(p.lastDetected) : "—"}
      />
    </DetectionCard>
  );
}
