import {
  LayoutDashboard,
  ScanFace,
  Timer,
  CheckSquare,
  Target,
  NotebookPen,
  BarChart3,
  Trophy,
  User,
  Settings,
  CircleHelp,
  Sparkles,
  CalendarClock,
  Beaker,
  Presentation,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
}

export const MAIN_NAV: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/focus", label: "Focus Monitor", icon: ScanFace },
  { href: "/timer", label: "Study Timer", icon: Timer },
  { href: "/tasks", label: "Tasks", icon: CheckSquare },
  { href: "/goals", label: "Goals", icon: Target },
  { href: "/notes", label: "Notes", icon: NotebookPen },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/lab", label: "AI Test Lab", icon: Beaker },
  { href: "/expo", label: "Expo Mode", icon: Presentation },
  { href: "/achievements", label: "Achievements", icon: Trophy },
];

export const TOOLS_NAV: NavItem[] = [
  { href: "/focus", label: "Focus Sessions", icon: Sparkles },
  { href: "/goals", label: "Study Planner", icon: CalendarClock },
];

export const ACCOUNT_NAV: NavItem[] = [
  { href: "/profile", label: "Profile", icon: User },
  { href: "/settings", label: "Settings", icon: Settings },
  { href: "/help", label: "Help", icon: CircleHelp },
];

/** Flat list used by global search. */
export const ALL_NAV: NavItem[] = [...MAIN_NAV, ...ACCOUNT_NAV];

/** Bottom nav (mobile) — the essentials. */
export const BOTTOM_NAV: NavItem[] = [
  { href: "/dashboard", label: "Home", icon: LayoutDashboard },
  { href: "/focus", label: "Focus", icon: ScanFace },
  { href: "/timer", label: "Timer", icon: Timer },
  { href: "/tasks", label: "Tasks", icon: CheckSquare },
  { href: "/analytics", label: "Stats", icon: BarChart3 },
];
