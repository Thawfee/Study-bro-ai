"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Sparkles } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { Avatar } from "@/components/ui/common";
import { useWorkspace } from "@/lib/store/workspace-store";
import { MAIN_NAV, TOOLS_NAV, ACCOUNT_NAV, type NavItem } from "./navItems";
import { cn } from "@/lib/utils";

function NavLink({ item, active, onNavigate }: { item: NavItem; active: boolean; onNavigate?: () => void }) {
  const Icon = item.icon;
  return (
    <Link
      href={item.href}
      onClick={onNavigate}
      aria-current={active ? "page" : undefined}
      className={cn(
        "group flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-medium transition-colors",
        active ? "bg-[var(--surface-2)] text-[var(--text)]" : "text-[var(--text-dim)] hover:bg-[var(--surface)] hover:text-[var(--text)]",
      )}
    >
      <span
        className={cn(
          "grid h-9 w-9 place-items-center rounded-xl border transition-colors",
          active
            ? "border-violet-400/40 bg-violet-500/15 text-violet-300"
            : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] group-hover:text-[var(--text)]",
        )}
      >
        <Icon size={16} />
      </span>
      <span>{item.label}</span>
      {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-violet-400" />}
    </Link>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return <p className="px-3 pb-1.5 pt-4 text-[10px] font-semibold uppercase tracking-[0.15em] text-[var(--text-faint)]">{children}</p>;
}

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  const { profile } = useWorkspace();
  const isActive = (href: string) => pathname === href;

  return (
    <div className="flex h-full flex-col p-3">
      <div className="rounded-[1.6rem] border border-[var(--border)] bg-[var(--surface)]/80 p-3 backdrop-blur-xl">
        <Link href="/" onClick={onNavigate} className="px-1 py-1">
          <Logo />
        </Link>
        <div className="mt-3 rounded-2xl border border-violet-400/20 bg-violet-500/10 p-3">
          <div className="flex items-center gap-2 text-violet-200">
            <Sparkles size={14} />
            <span className="text-xs font-semibold uppercase tracking-[0.16em]">Focus Fusion Engine</span>
          </div>
          <p className="mt-2 text-sm leading-relaxed text-[var(--text-dim)]">
            Premium study intelligence that detects, explains and intervenes when focus is lost.
          </p>
        </div>
      </div>

      <nav className="mt-3 flex-1 overflow-y-auto rounded-[1.6rem] border border-[var(--border)] bg-[var(--surface)]/70 p-2.5 backdrop-blur-xl">
        <div className="space-y-0.5">
          {MAIN_NAV.map((item) => (
            <NavLink key={item.href} item={item} active={isActive(item.href)} onNavigate={onNavigate} />
          ))}
        </div>

        <SectionLabel>Tools</SectionLabel>
        <div className="space-y-0.5">
          {TOOLS_NAV.map((item) => (
            <NavLink key={item.label} item={item} active={false} onNavigate={onNavigate} />
          ))}
        </div>

        <SectionLabel>Account</SectionLabel>
        <div className="space-y-0.5">
          {ACCOUNT_NAV.map((item) => (
            <NavLink key={item.href} item={item} active={isActive(item.href)} onNavigate={onNavigate} />
          ))}
        </div>

        <Link href="/" onClick={onNavigate} className="mt-2 flex items-center gap-2 rounded-xl px-3 py-2 text-xs text-[var(--text-faint)] transition-colors hover:bg-[var(--surface)] hover:text-[var(--text)]">
          <Home size={13} /> Back to landing
        </Link>
      </nav>

      <Link
        href="/profile"
        onClick={onNavigate}
        className="mt-3 flex items-center gap-3 rounded-[1.4rem] border border-[var(--border)] bg-[var(--surface)]/80 p-3 transition-colors hover:bg-[var(--surface-2)]"
      >
        <div className="relative">
          <Avatar name={profile.name} seed={profile.avatarSeed} size={38} />
          <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[var(--bg-elev)] bg-emerald-400" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-[var(--text)]">{profile.name}</p>
          <p className="text-[11px] text-emerald-400">● Online</p>
        </div>
      </Link>
    </div>
  );
}
