"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useStudyBro } from "@/lib/store/studybro-store";
import type { DetectionType } from "@/types/ai";

const META: Record<DetectionType, { label: string; color: string }> = {
  drowsiness: { label: "Sleep", color: "#a78bfa" },
  phone: { label: "Phone", color: "#fb7185" },
  distraction: { label: "Distraction", color: "#fbbf24" },
  posture: { label: "Posture", color: "#38bdf8" },
  away: { label: "Away", color: "#22d3ee" },
};

export function DetectionBreakdown() {
  const { events } = useStudyBro();

  const counts: Record<DetectionType, number> = {
    drowsiness: 0,
    phone: 0,
    distraction: 0,
    posture: 0,
    away: 0,
  };
  for (const e of events) {
    if (e.type !== "system") counts[e.type] += 1;
  }

  const data = (Object.keys(META) as DetectionType[]).map((t) => ({
    name: META[t].label,
    count: counts[t],
    color: META[t].color,
  }));

  const hasAny = data.some((d) => d.count > 0);

  return (
    <div className="card p-5">
      <h3 className="mb-1 text-sm font-semibold text-[var(--text)]">Detections by Type</h3>
      <p className="mb-4 text-xs text-[var(--text-dim)]">Count of alerts this session</p>
      <div className="h-56 w-full">
        {!hasAny ? (
          <div className="grid h-full place-items-center text-center text-xs text-[var(--text-faint)]">
            No detections yet.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: "#9aa4bd", fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fill: "#9aa4bd", fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip
                cursor={{ fill: "rgba(255,255,255,0.04)" }}
                contentStyle={{
                  background: "#0c1120",
                  border: "1px solid rgba(255,255,255,0.12)",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                labelStyle={{ color: "#e8ecf4" }}
                itemStyle={{ color: "#e8ecf4" }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]} maxBarSize={48}>
                {data.map((d) => (
                  <Cell key={d.name} fill={d.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
