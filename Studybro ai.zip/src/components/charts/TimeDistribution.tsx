"use client";

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatDuration } from "@/lib/utils";

const COLORS = {
  Focused: "#34d399",
  Distraction: "#fbbf24",
  Phone: "#fb7185",
  Drowsiness: "#a78bfa",
  Away: "#22d3ee",
};

export function TimeDistribution() {
  const { session } = useStudyBro();
  const m = session.metrics;

  const data = [
    { name: "Focused", value: m.focusedTimeMs },
    { name: "Distraction", value: m.distractionTimeMs },
    { name: "Phone", value: m.phoneUsageMs },
    { name: "Drowsiness", value: m.drowsinessMs },
    { name: "Away", value: m.awayMs },
  ].filter((d) => d.value > 0);

  const total = data.reduce((a, b) => a + b.value, 0);

  return (
    <div className="card p-5">
      <h3 className="mb-1 text-sm font-semibold text-[var(--text)]">Time Distribution</h3>
      <p className="mb-4 text-xs text-[var(--text-dim)]">Where this session&apos;s time went</p>

      {total === 0 ? (
        <div className="grid h-56 place-items-center text-center text-xs text-[var(--text-faint)]">
          No study time recorded yet. Start a session and trigger a few detections.
        </div>
      ) : (
        <div className="flex flex-col items-center gap-4 sm:flex-row">
          <div className="h-52 w-52 shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={58}
                  outerRadius={82}
                  paddingAngle={2}
                  stroke="none"
                >
                  {data.map((d) => (
                    <Cell key={d.name} fill={COLORS[d.name as keyof typeof COLORS]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(v) => formatDuration(Number(v))}
                  contentStyle={{
                    background: "#0c1120",
                    border: "1px solid rgba(255,255,255,0.12)",
                    borderRadius: 12,
                    fontSize: 12,
                  }}
                  labelStyle={{ color: "#e8ecf4" }}
                  itemStyle={{ color: "#e8ecf4" }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="flex-1 space-y-2">
            {data.map((d) => (
              <li key={d.name} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-[var(--text)]">
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: COLORS[d.name as keyof typeof COLORS] }}
                  />
                  {d.name}
                </span>
                <span className="tabular-nums text-[var(--text-dim)]">
                  {formatDuration(d.value)} · {Math.round((d.value / total) * 100)}%
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
