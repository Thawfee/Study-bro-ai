"use client";

import { useEffect, useRef, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useStudyBro } from "@/lib/store/studybro-store";
import { formatTime } from "@/lib/utils";

const MAX_POINTS = 40;

/** Live area chart: samples the real focus score once per engine tick. */
export function FocusTrend() {
  const { focus, now } = useStudyBro();
  const [points, setPoints] = useState<{ t: number; score: number }[]>([]);
  const lastSampled = useRef(0);

  useEffect(() => {
    if (!now || now === lastSampled.current) return;
    lastSampled.current = now;
    setPoints((prev) => [...prev, { t: now, score: focus.score }].slice(-MAX_POINTS));
  }, [now, focus.score]);

  return (
    <div className="card p-5">
      <div className="mb-1 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-[var(--text)]">Focus Score Trend</h3>
        <span className="text-xs text-[var(--text-dim)]">Live · this session</span>
      </div>
      <p className="mb-4 text-xs text-[var(--text-faint)]">Sampled every second from your live score</p>
      <div className="h-64 w-full">
        {points.length < 2 ? (
          <div className="grid h-full place-items-center text-center text-xs text-[var(--text-faint)]">
            Collecting live data… keep the session running.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={points} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
              <defs>
                <linearGradient id="focusGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#818cf8" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#818cf8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis
                dataKey="t"
                tickFormatter={(t) => formatTime(t)}
                tick={{ fill: "#9aa4bd", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                minTickGap={40}
              />
              <YAxis
                domain={[0, 100]}
                tick={{ fill: "#9aa4bd", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                labelFormatter={(t) => formatTime(t as number)}
                formatter={(v) => [String(v), "Score"] as [string, string]}
                contentStyle={{
                  background: "#0c1120",
                  border: "1px solid rgba(255,255,255,0.12)",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                labelStyle={{ color: "#e8ecf4" }}
                itemStyle={{ color: "#e8ecf4" }}
              />
              <Area
                type="monotone"
                dataKey="score"
                stroke="#818cf8"
                strokeWidth={2}
                fill="url(#focusGrad)"
                isAnimationActive={false}
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
