"use client";

import { Pause, Play, RotateCcw, Timer as TimerIcon } from "lucide-react";
import { useStudyTimer } from "@/hooks/useStudyTimer";
import { formatClock, cn } from "@/lib/utils";

const PRESETS = [15, 25, 45];

export function StudyTimer({ compact = false }: { compact?: boolean }) {
  const timer = useStudyTimer(25);
  const size = compact ? 128 : 160;
  const stroke = 10;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - timer.progress * c;

  return (
    <div className="card p-5">
      <div className="mb-4 flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg border border-indigo-400/30 bg-indigo-500/10 text-indigo-300">
          <TimerIcon size={16} />
        </span>
        <h3 className="text-sm font-semibold text-[var(--text)]">Study Timer</h3>
      </div>

      <div className="flex flex-col items-center">
        <div className="relative grid place-items-center" style={{ width: size, height: size }}>
          <svg width={size} height={size} className="-rotate-90">
            <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} />
            <circle
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              stroke="#818cf8"
              strokeWidth={stroke}
              strokeLinecap="round"
              strokeDasharray={c}
              strokeDashoffset={offset}
              style={{ transition: "stroke-dashoffset 1s linear", filter: "drop-shadow(0 0 5px #818cf866)" }}
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-4xl font-bold tabular-nums text-[var(--text)]">
              {formatClock(timer.secondsLeft)}
            </span>
            <span className="text-[11px] uppercase tracking-widest text-[var(--text-faint)]">
              {timer.isFinished ? "Done 🎉" : timer.isRunning ? "Focusing" : "Ready"}
            </span>
          </div>
        </div>

        {/* controls */}
        <div className="mt-5 flex items-center gap-2">
          {timer.isRunning ? (
            <button
              onClick={timer.pause}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2 text-sm font-medium text-[var(--text)] hover:bg-[var(--surface-2)]"
            >
              <Pause size={15} /> Pause
            </button>
          ) : (
            <button
              onClick={timer.start}
              className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-indigo-500 to-violet-500 px-5 py-2 text-sm font-semibold text-[var(--text)] shadow-lg shadow-indigo-500/25 transition-transform hover:scale-[1.02]"
            >
              <Play size={15} /> Start
            </button>
          )}
          <button
            onClick={timer.reset}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2 text-sm font-medium text-[var(--text)] hover:bg-[var(--surface-2)]"
          >
            <RotateCcw size={15} /> Reset
          </button>
        </div>

        {/* presets */}
        <div className="mt-4 flex items-center gap-2">
          {PRESETS.map((min) => {
            const activePreset = timer.totalSeconds === min * 60;
            return (
              <button
                key={min}
                onClick={() => timer.setMinutes(min)}
                className={cn(
                  "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                  activePreset
                    ? "border-indigo-400/40 bg-indigo-500/15 text-indigo-200"
                    : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] hover:text-[var(--text)]",
                )}
              >
                {min}m
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
