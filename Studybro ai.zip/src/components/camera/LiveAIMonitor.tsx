"use client";

import { useRef, useState } from "react";
import { Camera, CameraOff, Loader2, ShieldAlert, RefreshCw, Play, CheckCircle2, Sparkles, Shield, ScanLine } from "lucide-react";
import { useCamera } from "@/hooks/useCamera";
import { useVisionEngine, type LiveVision } from "@/hooks/useVisionEngine";
import { LiveModeBadge } from "@/components/brand/LiveModeBadge";
import { cn, formatDuration } from "@/lib/utils";
import type { Tone } from "@/lib/tone";
import { TONE } from "@/lib/tone";

const PROCESS = ["Face tracking", "Eye calibration", "Drowsiness", "Phone detection", "Head pose", "Gaze analysis", "Posture", "Presence"];

export function LiveAIMonitor({ className }: { className?: string }) {
  const { status, error, videoRef, start, stop } = useCamera();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [retryKey, setRetryKey] = useState(0);
  const [demoFallback, setDemoFallback] = useState(false);
  const [aspect, setAspect] = useState(4 / 3);
  const active = status === "active";
  const live = useVisionEngine(videoRef, canvasRef, active, retryKey);

  return (
    <div className={cn("card overflow-hidden border-[var(--border-strong)]", className)}>
      <div className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-x-0 top-0 z-0 h-28 bg-gradient-to-b from-violet-500/10 to-transparent" />

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-4 py-3">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/25 bg-violet-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-violet-200">
              <ScanLine size={13} /> AI Vision Scan
            </div>
            <h3 className="mt-2 text-lg font-semibold text-[var(--text)]">Live AI Monitor</h3>
            <p className="text-xs text-[var(--text-faint)]">Premium real-time focus analysis using your webcam</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden rounded-full border border-emerald-400/25 bg-emerald-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-emerald-200 sm:inline-flex">
              🔒 Privacy first
            </span>
            <LiveModeBadge className="backdrop-blur" />
          </div>
        </div>

        <div className="relative p-4 pt-3">
          <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:28px_28px] opacity-[0.15]" />

          {/* top overlay */}
          <div className="pointer-events-none absolute inset-x-7 top-6 z-10 flex items-center justify-between">
            <span className={cn(
              "pointer-events-auto inline-flex items-center gap-1.5 rounded-full border bg-black/45 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider backdrop-blur",
              live.calibrating ? "border-cyan-400/40 text-cyan-200" : "border-rose-400/40 text-rose-300",
            )}>
              <span className={cn("h-1.5 w-1.5 animate-pulse rounded-full", live.calibrating ? "bg-cyan-300" : "bg-rose-400")} />
              {live.status === "error"
                ? "AI models not loaded"
                : live.status === "loading"
                  ? "Loading AI models…"
                  : live.calibrating
                    ? `Calibrating ${live.calibrationProgress}%`
                    : live.status === "running"
                      ? "Live AI Monitoring"
                      : "Camera ready"}
            </span>
            {active && live.status === "running" && (
              <span className="rounded-full border border-white/10 bg-black/45 px-2.5 py-1 text-[11px] font-medium text-slate-200 backdrop-blur">
                {live.fps} FPS
              </span>
            )}
          </div>

          <div className="relative overflow-hidden rounded-[1.6rem] border border-[var(--border)] bg-black shadow-[0_30px_60px_-35px_rgba(0,0,0,0.85)]" style={{ aspectRatio: String(aspect) }}>
            <video
              ref={videoRef}
              onLoadedMetadata={(e) => {
                const v = e.currentTarget;
                if (v.videoWidth && v.videoHeight) setAspect(v.videoWidth / v.videoHeight);
              }}
              className={cn("absolute inset-0 h-full w-full object-cover", active ? "block" : "hidden")}
              playsInline
              muted
            />
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.06),transparent_28%),linear-gradient(180deg,transparent,rgba(0,0,0,0.18))]" />
            <canvas
              ref={canvasRef}
              className={cn("pointer-events-none absolute inset-0 h-full w-full object-cover", active ? "block" : "hidden")}
            />

            {active && live.status === "running" && live.calibrating && (
              <div className="pointer-events-none absolute inset-x-0 bottom-10 z-20 flex justify-center px-4">
                <div className="rounded-2xl border border-cyan-300/25 bg-black/65 px-4 py-3 text-center text-xs text-cyan-50 shadow-xl backdrop-blur-md">
                  <p className="font-semibold">Accuracy calibration in progress</p>
                  <p className="mt-1 text-cyan-100/75">Sit in your normal upright position, look at the screen, and keep your eyes open for a few seconds.</p>
                  <div className="mt-2 h-1.5 w-52 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-gradient-to-r from-cyan-300 to-violet-400 transition-all" style={{ width: `${live.calibrationProgress}%` }} />
                  </div>
                </div>
              </div>
            )}

            {active && live.status === "loading" && (
              <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center gap-2 bg-black/60 py-2 text-xs text-slate-200 backdrop-blur">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading AI models…
              </div>
            )}
            {active && live.status === "error" && (
              <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-center gap-3 bg-black/70 py-2 text-xs text-amber-200 backdrop-blur">
                {live.error}
                <button onClick={() => setRetryKey((k) => k + 1)} className="inline-flex items-center gap-1 rounded-md border border-white/15 bg-white/10 px-2 py-1 text-slate-100 hover:bg-white/20">
                  <RefreshCw size={12} /> Retry
                </button>
              </div>
            )}

            {!active && (
              <div className="absolute inset-0 grid place-items-center px-6 text-center">
                {status === "requesting" ? (
                  <div className="flex flex-col items-center gap-3 text-slate-300">
                    <Loader2 className="h-7 w-7 animate-spin" />
                    <p className="text-sm">Requesting camera…</p>
                  </div>
                ) : (status === "denied" || status === "unavailable" || status === "error") && !demoFallback ? (
                  <div className="flex max-w-sm flex-col items-center gap-3 rounded-[1.4rem] border border-amber-400/25 bg-black/45 px-6 py-7 backdrop-blur-md">
                    <span className="grid h-12 w-12 place-items-center rounded-xl border border-amber-400/30 bg-amber-500/10 text-amber-300"><ShieldAlert size={22} /></span>
                    <p className="text-sm font-medium text-slate-100">Camera access is needed for AI focus monitoring</p>
                    <p className="text-xs text-slate-400">{error}</p>
                    <div className="mt-1 flex gap-2">
                      <button onClick={start} className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-violet-500 to-indigo-500 px-3 py-1.5 text-sm font-semibold text-white hover:brightness-110">
                        <Camera size={15} /> Try Again
                      </button>
                      <button onClick={() => setDemoFallback(true)} className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-sm text-slate-200 hover:bg-white/10">
                        Continue in Demo Mode
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex max-w-xl flex-col items-center gap-4 rounded-[1.8rem] border border-white/10 bg-black/38 px-6 py-8 backdrop-blur-md">
                    <span className="grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br from-violet-500 to-indigo-600 text-2xl shadow-lg shadow-violet-500/30">👋</span>
                    <div>
                      <p className="text-xl font-semibold text-slate-100">Let&apos;s lock in with StudyBro AI.</p>
                      <p className="mt-2 max-w-md text-sm leading-relaxed text-slate-300">
                        Start monitoring to activate the Focus Fusion Engine. StudyBro watches face presence, eyes, gaze direction, phone usage and posture in real time — with a cleaner, more premium AI monitor.
                      </p>
                    </div>
                    <div className="grid w-full gap-2 sm:grid-cols-3">
                      {[
                        "Face + eyes tracking",
                        "Phone & distraction detection",
                        "Drowsiness intervention",
                      ].map((item) => (
                        <div key={item} className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-200">{item}</div>
                      ))}
                    </div>
                    <button onClick={start} className="mt-1 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-indigo-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-violet-500/25 hover:brightness-110">
                      <Play size={16} /> Start Monitoring
                    </button>
                    <div className="inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-500/8 px-3 py-1 text-[11px] text-emerald-200">
                      <Shield size={12} /> Used for real-time focus analysis. No recordings stored by default.
                    </div>
                    {demoFallback && <p className="text-[11px] text-amber-300">Demo Mode active — use the Demo Control Panel below to simulate detections.</p>}
                  </div>
                )}
              </div>
            )}
          </div>

          {active && (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)]/80 px-4 py-3 backdrop-blur-sm">
              <div className="flex flex-wrap items-center gap-3 text-xs text-[var(--text-dim)]">
                <span className="inline-flex items-center gap-1.5 text-[var(--text)]">
                  <Sparkles size={13} className="text-violet-300" /> On-device only
                </span>
                <span>no recordings stored</span>
                {live.status === "running" && <span className="tabular-nums text-[var(--text-faint)]">{live.calibrating ? `Calibrating · ${live.calibrationProgress}%` : `Tracking ${live.trackingQuality.toLowerCase()} · ${live.fps} FPS`}</span>}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setRetryKey((k) => k + 1)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-cyan-400/20 bg-cyan-500/10 px-3 py-1.5 text-xs text-cyan-100 hover:bg-cyan-500/15"
                  title="Relearn your neutral eye/head/posture baseline"
                >
                  <RefreshCw size={14} /> Recalibrate
                </button>
                <button onClick={stop} className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-1.5 text-xs text-[var(--text)] hover:bg-[var(--surface-2)]">
                  <CameraOff size={14} /> Stop monitoring
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {active && live.status === "running" && (
        <div className="border-t border-[var(--border)] px-4 py-3">
          <div className="flex flex-wrap gap-x-4 gap-y-1.5">
            {PROCESS.map((p) => (
              <span key={p} className="inline-flex items-center gap-1.5 text-[11px] text-[var(--text-dim)]">
                <CheckCircle2 size={12} className="text-emerald-400" /> {p}
              </span>
            ))}
          </div>
        </div>
      )}

      <LiveInfoStrip live={live} active={active} />
    </div>
  );
}

function InfoCell({ label, value, tone = "neutral" }: { label: string; value: string; tone?: Tone }) {
  return (
    <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)]/80 px-3 py-3 backdrop-blur-sm">
      <p className="text-[10px] font-medium uppercase tracking-wider text-[var(--text-faint)]">{label}</p>
      <p className={cn("mt-1 text-sm font-semibold", TONE[tone].text)}>{value}</p>
    </div>
  );
}

function cap(s: string): string {
  return s.charAt(0) + s.slice(1).toLowerCase();
}

function LiveInfoStrip({ live, active }: { live: LiveVision; active: boolean }) {
  const running = active && live.status === "running";
  const calibrated = running && !live.calibrating;
  const faceTone: Tone = !running ? "neutral" : live.face ? "good" : "warn";
  const eyeTone: Tone = !running || live.calibrating ? "neutral" : live.eyesClosed ? "bad" : "good";
  const drowsyTone: Tone = live.calibrating ? "neutral" : live.drowsy === "CRITICAL" ? "bad" : live.drowsy === "WARNING" ? "warn" : "good";
  const phoneTone: Tone = live.calibrating ? "neutral" : live.phone ? "bad" : "good";
  const gazeTone: Tone = live.calibrating ? "neutral" : live.gaze === "DISTRACTED" ? "bad" : live.gaze === "SLIGHTLY_DISTRACTED" ? "warn" : "good";
  const postureTone: Tone = live.calibrating ? "neutral" : live.posture === "BAD" ? "bad" : live.posture === "WARNING" ? "warn" : "good";

  const gazeVal = !running || !live.face
    ? "—"
    : live.gaze === "DISTRACTED"
      ? `Distracted · ${cap(live.gazeDirection)}`
      : live.gaze === "SLIGHTLY_DISTRACTED"
        ? `Looking ${cap(live.gazeDirection)}`
        : "Focused";

  return (
    <div className="border-t border-[var(--border)] p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-[var(--text)]">Live biometric-style signals</p>
          <p className="text-xs text-[var(--text-faint)]">Explainable behavior signals, not medical analysis</p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-8">
        <InfoCell label="Face" value={running ? (live.calibrating ? "Calibrating" : live.face ? `Detected · ${(live.faceConfidence * 100).toFixed(0)}%` : "Not detected") : "—"} tone={faceTone} />
        <InfoCell label="Eyes" value={running && live.face ? (live.calibrating ? "Learning baseline" : live.eyesClosed ? "Closed" : `Open · ${Math.round(((live.leftOpen + live.rightOpen) / 2) * 100)}%`) : "—"} tone={eyeTone} />
        <InfoCell label="Fatigue" value={running ? (live.calibrating ? "Standby" : cap(live.drowsy)) : "—"} tone={drowsyTone} />
        <InfoCell label="Phone" value={running ? (live.calibrating ? "Standby" : live.phone ? "Detected" : "None") : "—"} tone={phoneTone} />
        <InfoCell label="Gaze" value={live.calibrating && running ? "Calibrating center" : gazeVal} tone={gazeTone} />
        <InfoCell label="Posture" value={running ? (live.calibrating ? "Calibrating neutral" : live.postureReason ?? cap(live.posture)) : "—"} tone={postureTone} />
        <InfoCell label="Head pose" value={running && live.face ? (live.calibrating ? "Learning neutral" : `${Math.round(live.headYaw)}° / ${Math.round(live.headPitch)}°`) : "—"} tone={gazeTone} />
        <InfoCell label="Tracking" value={running ? (live.calibrating ? `${live.calibrationProgress}%` : live.trackingQuality === "LOCKED" ? "Locked" : "Recovering") : "—"} tone={live.trackingQuality === "DEGRADED" ? "warn" : calibrated ? "good" : "neutral"} />
      </div>
      {running && live.phone && (
        <p className="mt-3 text-center text-xs text-rose-300">📱 Phone usage detected for <span className="tabular-nums">{formatDuration(live.phoneUsageMs)}</span></p>
      )}
      {!active && <p className="mt-2 text-center text-[11px] text-[var(--text-faint)]">Start monitoring above to populate these with real AI values.</p>}
    </div>
  );
}
