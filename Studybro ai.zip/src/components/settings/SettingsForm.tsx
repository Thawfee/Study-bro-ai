"use client";

import { Volume2, Clock, Video, RefreshCw, PlayCircle, XCircle } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { useDemoAI } from "@/hooks/useDemoAI";
import { Toggle } from "@/components/ui/Toggle";
import { DEFAULT_VIDEO_SETTINGS } from "@/lib/alerts/videoAlerts";
import { cn } from "@/lib/utils";

function Row({
  icon: Icon,
  title,
  desc,
  children,
}: {
  icon: React.ElementType;
  title: string;
  desc: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-[var(--border)] py-4 last:border-0">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)]">
          <Icon size={16} />
        </span>
        <div>
          <p className="text-sm font-medium text-[var(--text)]">{title}</p>
          <p className="text-xs text-[var(--text-dim)]">{desc}</p>
        </div>
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

export function SettingsForm() {
  const { settings, updateSettings } = useStudyBro();
  const { triggerPhone } = useDemoAI();
  const disabled = !settings.videoAlertsEnabled;

  return (
    <div className="space-y-6">
      <div className="card p-5">
        <h3 className="mb-1 text-sm font-semibold text-[var(--text)]">Video Alerts</h3>
        <p className="mb-2 text-xs text-[var(--text-dim)]">
          Control the full-screen video popups. Turning them off keeps detections, focus score and
          the event feed fully working — only the video popup is disabled.
        </p>

        <Row icon={Video} title="Video Alerts" desc="Master switch for video popups">
          <Toggle
            checked={settings.videoAlertsEnabled}
            onChange={(v) => updateSettings({ videoAlertsEnabled: v })}
            label="Video alerts"
          />
        </Row>

        <Row icon={PlayCircle} title="Auto Play" desc="Start the video automatically when a popup opens">
          <Toggle
            checked={settings.autoPlay}
            onChange={(v) => updateSettings({ autoPlay: v })}
            label="Auto play"
            disabled={disabled}
          />
        </Row>

        <Row icon={XCircle} title="Auto Close" desc="For manual/demo alerts, close when the clip ends">
          <Toggle
            checked={settings.autoClose}
            onChange={(v) => updateSettings({ autoClose: v })}
            label="Auto close"
            disabled={disabled}
          />
        </Row>

        <Row icon={RefreshCw} title="Loop Video" desc="Repeat manual/demo alerts; live interventions loop until recovery">
          <Toggle
            checked={settings.loop}
            onChange={(v) => updateSettings({ loop: v })}
            label="Loop"
            disabled={disabled}
          />
        </Row>

        <Row
          icon={Clock}
          title="Alert Cooldown"
          desc="Minimum time between video popups (anti-spam)"
        >
          <div className="flex items-center gap-3">
            <input
              type="range"
              min={5}
              max={120}
              step={5}
              value={Math.round(settings.cooldownMs / 1000)}
              onChange={(e) => updateSettings({ cooldownMs: Number(e.target.value) * 1000 })}
              disabled={disabled}
              className="w-32 accent-indigo-500"
              aria-label="Alert cooldown seconds"
            />
            <span className="w-12 text-right text-sm tabular-nums text-[var(--text)]">
              {Math.round(settings.cooldownMs / 1000)}s
            </span>
          </div>
        </Row>

        <Row icon={Volume2} title="Volume" desc="Playback volume for alert videos">
          <div className="flex items-center gap-3">
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={settings.volume}
              onChange={(e) => updateSettings({ volume: Number(e.target.value) })}
              disabled={disabled}
              className="w-32 accent-indigo-500"
              aria-label="Volume"
            />
            <span className="w-12 text-right text-sm tabular-nums text-[var(--text)]">
              {settings.volume}%
            </span>
          </div>
        </Row>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            onClick={triggerPhone}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-2 text-sm font-semibold text-[var(--text)] shadow-lg shadow-indigo-500/25 transition-transform hover:scale-[1.02]"
          >
            <PlayCircle size={16} /> Test alert (phone)
          </button>
          <button
            onClick={() => updateSettings({ ...DEFAULT_VIDEO_SETTINGS })}
            className="inline-flex items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2 text-sm font-medium text-[var(--text)] hover:bg-[var(--surface-2)]"
          >
            <RefreshCw size={15} /> Reset to defaults
          </button>
          <span className={cn("text-xs", disabled ? "text-amber-300" : "text-[var(--text-faint)]")}>
            {disabled ? "Video alerts are OFF — test will show a toast." : "Settings save automatically."}
          </span>
        </div>
      </div>

      {/* Custom videos guide */}
      <div className="card p-5">
        <h3 className="mb-2 text-sm font-semibold text-[var(--text)]">Replacing alert videos</h3>
        <p className="text-sm leading-relaxed text-[var(--text-dim)]">
          Drop your own <code className="rounded bg-[var(--surface-2)] px-1 py-0.5 text-xs">.mp4</code> files
          into the project folder below — no code changes needed. Keep the exact filenames:
        </p>
        <div className="mt-3 rounded-lg border border-[var(--border)] bg-black/40 p-3 font-mono text-xs text-[var(--text-dim)]">
          public/videos/
          <div className="pl-4 text-[var(--text-dim)]">
            <div>sleep-1.mp4 <span className="text-[var(--text-faint)]">(drowsiness)</span></div>
            <div>sleep-2.mp4 <span className="text-[var(--text-faint)]">(drowsiness alternate)</span></div>
            <div>general-alert.mp4 <span className="text-[var(--text-faint)]">(phone / distraction / posture / away)</span></div>
          </div>
        </div>
        <p className="mt-3 text-xs text-[var(--text-faint)]">
          Only use videos you own or have permission to use. Missing files never crash the app — a
          standard notification is shown instead.
        </p>
      </div>
    </div>
  );
}
