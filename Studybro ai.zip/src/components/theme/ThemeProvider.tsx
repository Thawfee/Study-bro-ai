"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useSyncExternalStore } from "react";

export type ThemePref = "dark" | "light" | "system";
export type ResolvedTheme = "dark" | "light";

const STORAGE_KEY = "studybro.theme";

interface ThemeContextValue {
  theme: ThemePref;
  resolved: ResolvedTheme;
  setTheme: (t: ThemePref) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

/** Inline script (runs before paint) to avoid a flash of the wrong theme. */
export const themeInitScript = `(function(){try{var p=localStorage.getItem('${STORAGE_KEY}')||'dark';var m=window.matchMedia('(prefers-color-scheme: dark)').matches;var r=p==='system'?(m?'dark':'light'):p;document.documentElement.classList.remove('dark','light');document.documentElement.classList.add(r);}catch(e){document.documentElement.classList.add('dark');}})();`;

function systemTheme(): ResolvedTheme {
  if (typeof window === "undefined") return "dark";
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function apply(resolved: ResolvedTheme) {
  const el = document.documentElement;
  el.classList.remove("dark", "light");
  el.classList.add(resolved);
}

const THEME_EVENT = "studybro:theme";

function readPref(): ThemePref {
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    return v === "light" || v === "system" ? v : "dark";
  } catch {
    return "dark";
  }
}

function subscribePref(onChange: () => void) {
  window.addEventListener("storage", onChange);
  window.addEventListener(THEME_EVENT, onChange);
  return () => {
    window.removeEventListener("storage", onChange);
    window.removeEventListener(THEME_EVENT, onChange);
  };
}

function subscribeSystem(onChange: () => void) {
  const mq = window.matchMedia("(prefers-color-scheme: dark)");
  mq.addEventListener("change", onChange);
  return () => mq.removeEventListener("change", onChange);
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  // Theme preference and OS theme are external state: read them directly
  // (server render assumes dark, matching the pre-paint init script default).
  const theme = useSyncExternalStore<ThemePref>(subscribePref, readPref, () => "dark");
  const system = useSyncExternalStore<ResolvedTheme>(subscribeSystem, systemTheme, () => "dark");
  const resolved: ResolvedTheme = theme === "system" ? system : theme;

  // Keep the <html> class in sync (DOM side effect only — no state updates).
  useEffect(() => {
    apply(resolved);
  }, [resolved]);

  const setTheme = useCallback((t: ThemePref) => {
    try {
      localStorage.setItem(STORAGE_KEY, t);
    } catch {
      /* ignore */
    }
    window.dispatchEvent(new Event(THEME_EVENT));
  }, []);

  const value = useMemo(() => ({ theme, resolved, setTheme }), [theme, resolved, setTheme]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within <ThemeProvider>");
  return ctx;
}
