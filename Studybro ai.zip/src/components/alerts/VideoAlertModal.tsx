"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Activity, AlertTriangle, Play, RotateCcw, X } from "lucide-react";
import type { DetectionType } from "@/types/ai";

export type VideoAlertProps = {
  type: DetectionType;
  videoUrl: string;
  title: string;
  message: string;
  onClose: () => void;
  /** Behavior flags (sourced from user settings). */
  autoPlay?: boolean;
  autoClose?: boolean;
  loop?: boolean;
  volume?: number; // 0–100
  /** Live AI is watching for recovery and will close the modal automatically. */
  recoveryManaged?: boolean;
  recoveryHint?: string;
};

/**
 * Full-screen video alert. Robust by design: a missing / unplayable
 * video never breaks the flow — it degrades to a standard notification
 * card with the same message and the same "I'm Back" control.
 */
export function VideoAlertModal({
  type,
  videoUrl,
  title,
  message,
  onClose,
  autoPlay = true,
  autoClose = false,
  loop = false,
  volume = 80,
  recoveryManaged = false,
  recoveryHint,
}: VideoAlertProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const backBtnRef = useRef<HTMLButtonElement | null>(null);
  const [failed, setFailed] = useState(false);
  const [needsTap, setNeedsTap] = useState(false);
  const [progress, setProgress] = useState(0);

  const hasVideo = Boolean(videoUrl);

  // Escape to close + focus the primary action for accessibility.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !recoveryManaged) onClose();
    };
    document.addEventListener("keydown", onKey);
    backBtnRef.current?.focus();
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose, recoveryManaged]);

  // Apply volume + attempt autoplay.
  useEffect(() => {
    const el = videoRef.current;
    if (!el || !hasVideo) return;
    el.volume = Math.max(0, Math.min(1, volume / 100));
    if (autoPlay) {
      el.play()
        .then(() => setNeedsTap(false))
        .catch(() => setNeedsTap(true)); // autoplay blocked → offer manual play
    }
  }, [autoPlay, volume, hasVideo, videoUrl]);

  // Make recovery feel immediate and deterministic. Unmounting a <video>
  // usually stops playback by itself, but explicitly pausing/resetting avoids
  // a stray audio frame in some browsers when the live detector closes it.
  useEffect(() => {
    const el = videoRef.current;
    return () => {
      if (!el) return;
      el.pause();
      try { el.currentTime = 0; } catch { /* media may already be detached */ }
    };
  }, [videoUrl]);

  const manualPlay = useCallback(() => {
    videoRef.current?.play().then(() => setNeedsTap(false)).catch(() => setNeedsTap(true));
  }, []);

  const onTimeUpdate = () => {
    const el = videoRef.current;
    if (el && el.duration) setProgress(el.currentTime / el.duration);
  };

  const onEnded = () => {
    setProgress(1);
    if (autoClose && !loop) onClose();
  };

  const showFallback = !hasVideo || failed;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      {/* backdrop */}
      <button
        aria-label="Close alert"
        onClick={recoveryManaged ? undefined : onClose}
        className="absolute inset-0 cursor-default bg-black/70 backdrop-blur-md"
      />

      {/* panel */}
      <div className="relative w-full max-w-2xl animate-scale-in overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--bg-elev)] shadow-2xl shadow-black/60">
        {/* accent top bar */}
        <div className="h-1 w-full bg-gradient-to-r from-indigo-500 via-fuchsia-500 to-cyan-400" />

        {/* header */}
        <div className="flex items-start justify-between gap-4 px-5 pt-4 sm:px-6">
          <div>
            {recoveryManaged && (
              <span className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-emerald-300">
                <Activity size={11} className="animate-pulse" /> Live intervention · recovery monitoring
              </span>
            )}
            <h2 className="text-xl font-bold text-[var(--text)] sm:text-2xl">{title}</h2>
            <p className="mt-1 text-sm text-[var(--text-dim)]">{message}</p>
            {recoveryManaged && recoveryHint && (
              <p className="mt-2 text-xs font-medium text-emerald-300/90">{recoveryHint}</p>
            )}
          </div>
          {!recoveryManaged && (
            <button
              onClick={onClose}
              aria-label="Dismiss"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-dim)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
            >
              <X size={18} />
            </button>
          )}
        </div>

        {/* media area */}
        <div className="px-5 pt-4 sm:px-6">
          <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-[var(--border)] bg-black">
            {showFallback ? (
              <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
                <AlertTriangle className="h-8 w-8 text-amber-300" />
                <p className="text-sm font-medium text-[var(--text)]">
                  Alert video unavailable
                </p>
                <p className="max-w-sm text-xs text-[var(--text-dim)]">
                  Continuing with a standard StudyBro notification. Add{" "}
                  <code className="rounded bg-[var(--surface-2)] px-1 py-0.5 text-[11px] text-[var(--text)]">
                    {type === "drowsiness" ? "sleep-1.mp4 / sleep-2.mp4" : "general-alert.mp4"}
                  </code>{" "}
                  to <code className="text-[11px] text-[var(--text)]">/public/videos/</code> to
                  enable it.
                </p>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  src={videoUrl}
                  className="h-full w-full object-contain"
                  playsInline
                  loop={loop}
                  autoPlay={autoPlay}
                  controls={false}
                  onError={() => setFailed(true)}
                  onTimeUpdate={onTimeUpdate}
                  onEnded={onEnded}
                />
                {needsTap && (
                  <button
                    onClick={manualPlay}
                    className="absolute inset-0 grid place-items-center bg-black/40 text-[var(--text)]"
                  >
                    <span className="flex flex-col items-center gap-2">
                      <span className="grid h-14 w-14 place-items-center rounded-full bg-white/15 backdrop-blur">
                        <Play className="h-6 w-6 translate-x-0.5" />
                      </span>
                      <span className="text-xs font-medium">Tap to play</span>
                    </span>
                  </button>
                )}
              </>
            )}
          </div>

          {/* progress */}
          {!showFallback && (
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-[var(--surface-2)]">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-400 to-cyan-300 transition-[width] duration-200"
                style={{ width: `${Math.round(progress * 100)}%` }}
              />
            </div>
          )}
        </div>

        {/* actions */}
        <div className="flex flex-col-reverse gap-2 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p className="text-[11px] text-[var(--text-faint)]">
            {recoveryManaged ? (
              <>AI keeps checking your live state · <span className="text-emerald-300/80">auto-stops on recovery</span></>
            ) : (
              <>Press <kbd className="rounded border border-white/15 bg-[var(--surface)] px-1.5 py-0.5">Esc</kbd> to dismiss</>
            )}
          </p>
          <div className="flex gap-2">
            {!showFallback && (
              <button
                onClick={() => {
                  const el = videoRef.current;
                  if (el) {
                    el.currentTime = 0;
                    el.play().catch(() => {});
                  }
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm font-medium text-[var(--text)] transition-colors hover:bg-[var(--surface-2)]"
              >
                <RotateCcw size={15} /> Replay
              </button>
            )}
            {recoveryManaged ? (
              <span className="inline-flex items-center gap-2 rounded-lg border border-emerald-400/25 bg-emerald-500/10 px-4 py-2 text-sm font-semibold text-emerald-200">
                <Activity size={15} className="animate-pulse" /> Waiting for live recovery
              </span>
            ) : (
              <button
                ref={backBtnRef}
                onClick={onClose}
                className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-indigo-500 to-violet-500 px-5 py-2 text-sm font-semibold text-[var(--text)] shadow-lg shadow-indigo-500/25 transition-transform hover:scale-[1.02] active:scale-[0.98]"
              >
                I&apos;m Back 👋
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
