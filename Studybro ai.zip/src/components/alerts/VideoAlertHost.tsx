"use client";

import { useEffect } from "react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { VideoAlertModal } from "./VideoAlertModal";

/** Bridges the central store to the modal, and locks page scroll while open. */
export function VideoAlertHost() {
  const { activeAlert, closeAlert, settings, mode } = useStudyBro();

  useEffect(() => {
    if (!activeAlert) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [activeAlert]);

  if (!activeAlert) return null;

  // In live monitoring, phone/drowsiness interventions are state-controlled:
  // keep the short clip playing while the condition remains true, then the
  // store automatically closes the modal as soon as recovery is confirmed.
  const recoveryManaged = mode === "live" && (
    activeAlert.type === "phone" ||
    activeAlert.type === "drowsiness" ||
    activeAlert.type === "distraction" ||
    activeAlert.type === "away" ||
    activeAlert.type === "posture"
  );

  const recoveryHint = activeAlert.type === "phone"
    ? "Put the phone away — this alert will stop automatically."
    : activeAlert.type === "drowsiness"
      ? "Open your eyes and stay alert — this alert will stop automatically."
      : "Return to your study state — this alert will stop automatically.";

  return (
    <VideoAlertModal
      type={activeAlert.type}
      videoUrl={activeAlert.videoUrl}
      title={activeAlert.title}
      message={activeAlert.message}
      onClose={closeAlert}
      autoPlay={settings.autoPlay}
      autoClose={recoveryManaged ? false : settings.autoClose}
      loop={recoveryManaged ? true : settings.loop}
      volume={settings.volume}
      recoveryManaged={recoveryManaged}
      recoveryHint={recoveryManaged ? recoveryHint : undefined}
    />
  );
}
