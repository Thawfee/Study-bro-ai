"use client";

import { useEffect } from "react";
import { X } from "lucide-react";
import { useStudyBro } from "@/lib/store/studybro-store";
import { severityTone, TONE } from "@/lib/tone";
import { cn } from "@/lib/utils";
import type { ToastMessage } from "@/types/alerts";

const TOAST_TTL = 4200;

function Toast({ toast, onClose }: { toast: ToastMessage; onClose: () => void }) {
  useEffect(() => {
    const id = setTimeout(onClose, TOAST_TTL);
    return () => clearTimeout(id);
  }, [onClose]);

  const t = TONE[severityTone(toast.severity)];
  return (
    <div
      role="status"
      className={cn(
        "pointer-events-auto flex w-80 max-w-[90vw] items-start gap-3 rounded-xl border p-3 shadow-xl shadow-black/40 glass-strong animate-fade-up",
        t.border,
      )}
    >
      <span className="text-lg leading-none">{toast.icon}</span>
      <div className="min-w-0 flex-1">
        <p className={cn("text-sm font-semibold", t.text)}>{toast.title}</p>
        <p className="truncate text-xs text-[var(--text-dim)]">{toast.message}</p>
      </div>
      <button
        onClick={onClose}
        aria-label="Dismiss notification"
        className="rounded-md p-1 text-[var(--text-dim)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
      >
        <X size={14} />
      </button>
    </div>
  );
}

/** Renders the stack of non-blocking toasts (top-right). */
export function ToastHost() {
  const { toasts, dismissToast } = useStudyBro();
  if (toasts.length === 0) return null;
  return (
    <div className="fixed right-4 top-4 z-[90] flex flex-col gap-2 sm:right-6 sm:top-6">
      {toasts.map((t) => (
        <Toast key={t.id} toast={t} onClose={() => dismissToast(t.id)} />
      ))}
    </div>
  );
}
