# Alert Videos

StudyBro plays one of these clips when a detection fires.

| File                | Used for                                   |
| ------------------- | ------------------------------------------ |
| `sleep-1.mp4`       | Drowsiness (picked at random with sleep-2) |
| `sleep-2.mp4`       | Drowsiness (alternate)                     |
| `general-alert.mp4` | Phone, distraction, posture and away       |

## Replacing a video

Replace a file above with your own `.mp4`, keeping the exact filename. No code
changes are needed. If a file is missing, the alert shows a standard
notification instead. The app does not crash.

## Adding more clips

`src/lib/alerts/videoAlerts.ts` keeps a list of videos for each detection
(`videos: [...]`). Add more paths there and `pickVideo()` chooses one at random.

Only use videos you own or have permission to use. Do not add copyrighted
social-media clips.
